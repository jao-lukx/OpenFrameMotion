// SPDX-License-Identifier: GPL-3.0-or-later
package org.openframe.export

import android.graphics.Bitmap
import android.graphics.Color
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import androidx.test.platform.app.InstrumentationRegistry
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import org.openframe.model.*
import org.openframe.rendering.CompositionRenderer
import java.io.File
import kotlin.math.abs

/** Runs against a real device/emulator codec, never a mocked encoder. */
class VideoExporterTest {
    private val cache: File get() = InstrumentationRegistry.getInstrumentation().targetContext.cacheDir

    @Test fun mp4ContainsAnimatedCompositionAndMatchesReferenceFrames() = runBlocking {
        val project = sampleProject()
        val output = File(cache, "export-test-${newId()}.mp4")
        val progress = mutableListOf<Float>()
        try {
            VideoExporter(cache).export(project, output) { progress += it }
            assertTrue(output.length() > 1000)
            assertEquals(0f, progress.first(), 0.0001f)
            assertEquals(1f, progress.last(), 0.0001f)
            assertTrue(progress.zipWithNext().all { (a, b) -> b >= a })
            val extractor = MediaExtractor()
            try {
                extractor.setDataSource(output.path)
                assertEquals(1, extractor.trackCount)
                val format = extractor.getTrackFormat(0)
                assertEquals("video/avc", format.getString(MediaFormat.KEY_MIME))
                assertEquals(320, format.getInteger(MediaFormat.KEY_WIDTH))
                assertEquals(240, format.getInteger(MediaFormat.KEY_HEIGHT))
                extractor.selectTrack(0)
                val timestamps = mutableListOf<Long>()
                do { if (extractor.sampleTime >= 0) timestamps += extractor.sampleTime } while (extractor.advance())
                assertEquals(12, timestamps.size)
                assertTrue(timestamps.zipWithNext().all { (a, b) -> b > a })
                assertEquals(0L, timestamps.first())
                assertTrue(abs(timestamps.last() - 458333L) < 3L)
            } finally { extractor.release() }
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(output.path)
                CompositionRenderer(cache).use { renderer ->
                    for (timeMs in listOf(0L, 250L)) {
                        val decoded = checkNotNull(retriever.getFrameAtTime(timeMs * 1000, MediaMetadataRetriever.OPTION_CLOSEST))
                        val reference = renderer.renderBitmap(project, timeMs, 320, 240)
                        try { assertTrue("Preview/export mean RGB error too large at $timeMs ms", meanError(reference, decoded) < 18.0) }
                        finally { decoded.recycle(); reference.recycle() }
                    }
                }
            } finally { retriever.release() }
        } finally { output.delete() }
    }

    @Test fun cancellationRemovesPartialFile() = runBlocking {
        val output = File(cache, "export-cancel-${newId()}.mp4")
        try {
            VideoExporter(cache).export(sampleProject(), output) { if (it > 0f) throw CancellationException("Test cancellation") }
            fail("Expected cancellation")
        } catch (_: CancellationException) {
            assertFalse(output.exists())
        } finally { output.delete() }
    }

    @Test fun missingMediaFailsInsteadOfExportingPlaceholder() = runBlocking {
        val output = File(cache, "export-missing-${newId()}.mp4")
        val project = sampleProject().copy(layers = listOf(Layer(type = LayerType.IMAGE, durationMs = 500, mediaRef = "missing-${newId()}.png")))
        try {
            VideoExporter(cache).export(project, output) {}
            fail("Expected unavailable media error")
        } catch (error: IllegalStateException) {
            assertTrue(error.message.orEmpty().contains("Mídia indisponível"))
            assertFalse(output.exists())
        } finally { output.delete() }
    }

    private fun sampleProject() = MotionProject(width = 320, height = 240, fps = 24, durationMs = 500,
        backgroundColor = 0xFF142337,
        layers = listOf(
            Layer(width = 60f, height = 70f, durationMs = 500, color = 0xFF75E2C0,
                transform = Transform(x = 60f, y = 70f),
                tracks = listOf(AnimationTrack(AnimatedProperty.X, listOf(Keyframe(0, 60f), Keyframe(500, 260f))))),
            Layer(type = LayerType.TEXT, text = "OPEN", width = 200f, height = 60f, fontSize = 32f,
                durationMs = 500, color = 0xFFF5F5F5, transform = Transform(x = 160f, y = 180f)),
        ))

    private fun meanError(expected: Bitmap, actual: Bitmap): Double {
        assertEquals(expected.width, actual.width)
        assertEquals(expected.height, actual.height)
        var error = 0L
        var samples = 0
        for (y in 4 until expected.height step 7) for (x in 4 until expected.width step 7) {
            val a = expected.getPixel(x, y)
            val b = actual.getPixel(x, y)
            error += abs(Color.red(a) - Color.red(b)) + abs(Color.green(a) - Color.green(b)) + abs(Color.blue(a) - Color.blue(b))
            samples += 3
        }
        return error.toDouble() / samples
    }
}
