// SPDX-License-Identifier: GPL-3.0-or-later
package org.openframe.export

import android.graphics.Bitmap
import android.graphics.Canvas
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaFormat
import android.media.MediaMuxer
import android.os.SystemClock
import android.view.Surface
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.openframe.model.MotionProject
import org.openframe.model.validated
import org.openframe.rendering.CompositionRenderer
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

/**
 * Offline MP4/H.264 export of the actual composition, without audio or watermark.
 * Canvas composites every frame; GLES uploads that frame to a MediaCodec input Surface.
 * This reference implementation is intentionally capped at 720p and 60 seconds.
 */
class VideoExporter(private val mediaDirectory: File) {
    suspend fun export(project: MotionProject, output: File, onProgress: (Float) -> Unit) {
        project.validated()
        require(!output.exists()) { "O arquivo de exportação já existe" }
        // An EGL context is bound to a physical thread, not a coroutine worker pool.
        Executors.newSingleThreadExecutor { runnable -> Thread(runnable, "OpenFrame-export") }
            .asCoroutineDispatcher().use { dispatcher ->
                withContext(dispatcher) { exportOnWorker(project, output, onProgress) }
            }
    }

    private suspend fun exportOnWorker(project: MotionProject, output: File, onProgress: (Float) -> Unit) {
        val coroutine = currentCoroutineContext()
        val (width, height) = outputSize(project)
        val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, (width.toLong() * height * project.fps / 5).coerceIn(1_000_000, 8_000_000).toInt())
            setInteger(MediaFormat.KEY_FRAME_RATE, project.fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }
        val codecName = MediaCodecList(MediaCodecList.REGULAR_CODECS).findEncoderForFormat(format)
            ?: error("Este dispositivo não possui encoder H.264 compatível com ${width}×$height a ${project.fps} FPS")
        var codec: MediaCodec? = null
        var inputSurface: Surface? = null
        var egl: EncoderSurface? = null
        var muxer: MediaMuxer? = null
        var renderer: CompositionRenderer? = null
        var frame: Bitmap? = null
        var codecStarted = false
        var muxerStarted = false
        var success = false
        try {
            coroutine.ensureActive()
            output.parentFile?.let { check(it.isDirectory || it.mkdirs()) { "Diretório de exportação indisponível" } }
            val encoder = MediaCodec.createByCodecName(codecName).also { codec = it }
            encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            val surface = encoder.createInputSurface().also { inputSurface = it }
            val encoderSurface = EncoderSurface(surface, width, height).also { egl = it }
            encoder.start()
            codecStarted = true
            val videoMuxer = MediaMuxer(output.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4).also { muxer = it }
            val compositor = CompositionRenderer(mediaDirectory).also { renderer = it }
            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888).also { frame = it }
            val canvas = Canvas(bitmap)
            val bufferInfo = MediaCodec.BufferInfo()
            var track = -1
            var sawEndOfStream = false
            var writtenFrames = 0
            var lastPresentationUs = -1L

            fun drain(waitForEnd: Boolean) {
                val startedAt = SystemClock.elapsedRealtime()
                while (!sawEndOfStream) {
                    coroutine.ensureActive()
                    val index = encoder.dequeueOutputBuffer(bufferInfo, if (waitForEnd) 10_000 else 0)
                    when {
                        index == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                            if (!waitForEnd) return
                            check(SystemClock.elapsedRealtime() - startedAt < 30_000) { "Encoder não finalizou em 30 segundos" }
                        }
                        index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            check(!muxerStarted) { "Formato do encoder alterado inesperadamente" }
                            track = videoMuxer.addTrack(encoder.outputFormat)
                            videoMuxer.start()
                            muxerStarted = true
                        }
                        index >= 0 -> {
                            try {
                                if (bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) bufferInfo.size = 0
                                if (bufferInfo.size > 0) {
                                    check(muxerStarted && track >= 0) { "Encoder enviou frame antes do formato" }
                                    check(bufferInfo.presentationTimeUs >= lastPresentationUs) { "Timestamps fora de ordem" }
                                    val buffer = checkNotNull(encoder.getOutputBuffer(index))
                                    buffer.position(bufferInfo.offset)
                                    buffer.limit(bufferInfo.offset + bufferInfo.size)
                                    videoMuxer.writeSampleData(track, buffer, bufferInfo)
                                    lastPresentationUs = bufferInfo.presentationTimeUs
                                    writtenFrames++
                                }
                                sawEndOfStream = bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                            } finally {
                                encoder.releaseOutputBuffer(index, false)
                            }
                        }
                    }
                }
            }

            val frameCount = ((project.durationMs * project.fps + 999) / 1000).toInt()
            onProgress(0f)
            for (frameIndex in 0 until frameCount) {
                coroutine.ensureActive()
                drain(waitForEnd = false)
                val presentationNs = frameIndex.toLong() * 1_000_000_000L / project.fps
                compositor.render(canvas, project, presentationNs / 1_000_000, width, height)
                check(compositor.missingMedia.isEmpty()) { "Mídia indisponível: ${compositor.missingMedia.joinToString()}" }
                encoderSurface.draw(bitmap, presentationNs)
                drain(waitForEnd = false)
                if (frameIndex % max(1, project.fps / 5) == 0) onProgress((frameIndex + 1f) / frameCount * 0.98f)
            }
            encoder.signalEndOfInputStream()
            drain(waitForEnd = true)
            check(muxerStarted && writtenFrames > 0) { "Nenhum frame foi codificado" }
            coroutine.ensureActive()
            videoMuxer.stop()
            muxerStarted = false
            check(output.length() > 0) { "O encoder produziu um arquivo vazio" }
            onProgress(1f)
            success = true
        } finally {
            renderer?.close()
            frame?.recycle()
            runCatching { egl?.close() }
            if (codecStarted) runCatching { codec?.stop() }
            runCatching { codec?.release() }
            runCatching { inputSurface?.release() }
            if (muxerStarted) runCatching { muxer?.stop() }
            runCatching { muxer?.release() }
            if (!success) output.delete()
        }
    }

    companion object {
        /** Width/height stay even for H.264. Any subpixel aspect difference is letterboxed by the compositor. */
        fun outputSize(project: MotionProject): Pair<Int, Int> {
            val shortSide = min(project.width, project.height)
            val longSide = max(project.width, project.height)
            val scale = min(1.0, min(720.0 / shortSide, 1280.0 / longSide))
            val width = ((project.width * scale).toInt() / 2 * 2).coerceAtLeast(2)
            val height = ((project.height * scale).toInt() / 2 * 2).coerceAtLeast(2)
            return width to height
        }
    }
}
