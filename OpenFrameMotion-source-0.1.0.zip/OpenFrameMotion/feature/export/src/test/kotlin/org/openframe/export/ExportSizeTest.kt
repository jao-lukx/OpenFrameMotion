// SPDX-License-Identifier: GPL-3.0-or-later
package org.openframe.export

import org.junit.Assert.assertEquals
import org.junit.Test
import org.openframe.model.MotionProject

class ExportSizeTest {
    @Test fun portraitLandscapeAndSquareStayInside720pBudget() {
        assertEquals(720 to 1280, VideoExporter.outputSize(MotionProject(width = 1080, height = 1920)))
        assertEquals(1280 to 720, VideoExporter.outputSize(MotionProject(width = 1920, height = 1080)))
        assertEquals(720 to 720, VideoExporter.outputSize(MotionProject(width = 1080, height = 1080)))
    }

    @Test fun smallImagesAreNeverUpscaledAndDimensionsAreEven() {
        assertEquals(320 to 240, VideoExporter.outputSize(MotionProject(width = 320, height = 240)))
        assertEquals(320 to 240, VideoExporter.outputSize(MotionProject(width = 321, height = 241)))
        assertEquals(1280 to 20, VideoExporter.outputSize(MotionProject(width = 4096, height = 64)))
    }
}
