// SPDX-License-Identifier: GPL-3.0-or-later
package org.openframe.editor

import android.graphics.Paint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import org.openframe.model.MotionProject
import java.util.Locale
import kotlin.math.ceil
import kotlin.math.roundToLong

internal fun formatSeconds(timeMs: Long): String = String.format(Locale.ROOT, "%.2f", timeMs / 1000f)

@Composable
internal fun Timeline(project: MotionProject, state: StudioState, actions: StudioActions) {
    var zoom by remember(project.id) { mutableFloatStateOf(1f) }
    val horizontal = rememberScrollState()
    val layers = project.layers.asReversed()
    Column(Modifier.fillMaxWidth().background(Panel).padding(vertical = 8.dp)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("TIMELINE", style = MaterialTheme.typography.labelSmall, color = Lilac, modifier = Modifier.weight(1f))
            Text("${formatSeconds(state.playheadMs)} / ${formatSeconds(project.durationMs)} s", style = MaterialTheme.typography.labelMedium)
            TextButton(onClick = { zoom = (zoom / 1.5f).coerceAtLeast(1f) }, enabled = zoom > 1f, modifier = Modifier.width(44.dp), contentPadding = PaddingValues(0.dp)) { Text("−") }
            Text("${zoom.toInt()}×", style = MaterialTheme.typography.labelSmall)
            TextButton(onClick = { zoom = (zoom * 1.5f).coerceAtMost(12f) }, enabled = zoom < 12f, modifier = Modifier.width(44.dp), contentPadding = PaddingValues(0.dp)) { Text("+") }
        }
        Slider(value = state.playheadMs.toFloat(), onValueChange = { actions.seek(it.roundToLong()) }, valueRange = 0f..project.durationMs.toFloat(), modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp).semantics { contentDescription = "Posição na timeline" })
        if (layers.isEmpty()) {
            Text("Adicione uma camada para começar.", Modifier.padding(18.dp), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
        } else {
            Row(Modifier.heightIn(max = 230.dp).verticalScroll(rememberScrollState())) {
                Column(Modifier.width(106.dp)) {
                    Box(Modifier.height(28.dp).fillMaxWidth(), contentAlignment = Alignment.CenterStart) {
                        Text("Camadas", Modifier.padding(start = 12.dp), style = MaterialTheme.typography.labelSmall)
                    }
                    layers.forEach { layer ->
                        val selected = layer.id == state.selectedLayerId
                        Row(Modifier.height(44.dp).fillMaxWidth().background(if (selected) Mint.copy(alpha = 0.13f) else Color.Transparent).clickable { actions.selectLayer(layer.id) }.padding(start = 10.dp, end = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(if (layer.visible) "●" else "○", color = if (selected) Mint else Lilac, style = MaterialTheme.typography.labelSmall)
                            Text(layer.name, Modifier.padding(start = 5.dp), maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.labelSmall, color = if (layer.visible) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                BoxWithConstraints(Modifier.weight(1f)) {
                    val timelineWidth = maxWidth * zoom
                    val labelPaint = remember { Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.LTGRAY } }
                    Column(Modifier.horizontalScroll(horizontal)) {
                        Canvas(Modifier.width(timelineWidth).height(28.dp + 44.dp * layers.size).pointerInput(project, zoom, state.selectedLayerId) {
                            detectTapGestures { tap ->
                                val time = (tap.x / size.width * project.durationMs).roundToLong().coerceIn(0, project.durationMs)
                                val row = ((tap.y - 28.dp.toPx()) / 44.dp.toPx()).toInt()
                                if (tap.y >= 28.dp.toPx() && row in layers.indices) actions.selectLayer(layers[row].id)
                                actions.seek(time)
                            }
                        }.semantics { contentDescription = "Faixas da timeline; toque para selecionar e posicionar" }) {
                            val header = 28.dp.toPx()
                            val rowHeight = 44.dp.toPx()
                            val duration = project.durationMs.toFloat()
                            labelPaint.textSize = 10.dp.toPx()
                            val step = maxOf(1, ceil(project.durationMs / 1000.0 / (6 * zoom)).toInt())
                            for (second in 0..ceil(project.durationMs / 1000.0).toInt() step step) {
                                val x = second * 1000f / duration * size.width
                                drawLine(Color.White.copy(alpha = 0.09f), Offset(x, header), Offset(x, size.height))
                                drawContext.canvas.nativeCanvas.drawText("${second}s", x + 4.dp.toPx(), 17.dp.toPx(), labelPaint)
                            }
                            layers.forEachIndexed { index, layer ->
                                val y = header + rowHeight * index
                                val start = layer.startMs / duration * size.width
                                val width = layer.durationMs / duration * size.width
                                val selected = layer.id == state.selectedLayerId
                                val color = if (selected) Mint else Lilac
                                if (selected) drawRect(Mint.copy(alpha = 0.05f), Offset(0f, y), Size(size.width, rowHeight))
                                drawRoundRect(color.copy(alpha = if (layer.visible) 0.55f else 0.16f), Offset(start, y + 6.dp.toPx()), Size(width.coerceAtLeast(2.dp.toPx()), rowHeight - 12.dp.toPx()), CornerRadius(6.dp.toPx()))
                                layer.tracks.flatMap { it.keyframes }.map { it.timeMs }.distinct().forEach { localTime ->
                                    val x = (layer.startMs + localTime) / duration * size.width
                                    val cy = y + rowHeight / 2f
                                    val r = 4.dp.toPx()
                                    val diamond = Path().apply { moveTo(x, cy - r); lineTo(x + r, cy); lineTo(x, cy + r); lineTo(x - r, cy); close() }
                                    drawPath(diamond, Color.White)
                                }
                                drawLine(Color.White.copy(alpha = 0.05f), Offset(0f, y + rowHeight), Offset(size.width, y + rowHeight))
                            }
                            val playhead = state.playheadMs / duration * size.width
                            drawLine(Mint, Offset(playhead, 0f), Offset(playhead, size.height), 2.dp.toPx())
                            drawCircle(Mint, 4.dp.toPx(), Offset(playhead, 5.dp.toPx()))
                        }
                    }
                }
            }
            if (zoom > 1f) Text("Deslize as faixas na horizontal para navegar.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(start = 12.dp, top = 8.dp))
        }
    }
}
