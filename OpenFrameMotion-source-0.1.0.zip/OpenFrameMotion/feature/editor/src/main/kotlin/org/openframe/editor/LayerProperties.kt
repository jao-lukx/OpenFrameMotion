// SPDX-License-Identifier: GPL-3.0-or-later
package org.openframe.editor

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import org.openframe.animation.AnimationEngine
import org.openframe.model.*
import java.util.Locale
import kotlin.math.abs

@Composable
internal fun LayerProperties(project: MotionProject, layer: Layer, timeMs: Long, actions: StudioActions) {
    var property by remember(layer.id) { mutableStateOf(AnimatedProperty.X) }
    var rename by remember(layer.id) { mutableStateOf(false) }
    var editText by remember(layer.id) { mutableStateOf(false) }
    val transform = AnimationEngine.evaluate(layer, timeMs)
    val track = layer.tracks.firstOrNull { it.property == property }
    val localTime = timeMs - layer.startMs
    val keyframe = track?.keyframes?.firstOrNull { it.timeMs == localTime }
    var easing by remember(layer.id, property, keyframe) { mutableStateOf(keyframe?.easing ?: Easing.LINEAR) }
    val atLayerTime = localTime >= 0 && localTime < layer.durationMs
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("PROPRIEDADES", style = MaterialTheme.typography.labelSmall, color = Lilac)
                Text(layer.name, style = MaterialTheme.typography.titleLarge)
            }
            TextButton(onClick = { rename = true }) { Text("Renomear") }
            Switch(checked = layer.visible, onCheckedChange = { actions.updateLayer(layer.copy(visible = it)) }, modifier = Modifier.semantics { contentDescription = "Visibilidade da camada" })
        }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedButton(onClick = actions::duplicateSelectedLayer, enabled = project.layers.size < 64) { Text("Duplicar") }
            OutlinedButton(onClick = { actions.moveSelectedLayer(1) }, enabled = project.layers.indexOfFirst { it.id == layer.id } < project.layers.lastIndex) { Text("↑ Frente") }
            OutlinedButton(onClick = { actions.moveSelectedLayer(-1) }, enabled = project.layers.indexOfFirst { it.id == layer.id } > 0) { Text("↓ Trás") }
            TextButton(onClick = actions::deleteSelectedLayer) { Text("Excluir", color = MaterialTheme.colorScheme.error) }
        }
        if (layer.type != LayerType.IMAGE) {
            ColorPicker(layer.color) { actions.updateLayer(layer.copy(color = it)) }
        }
        if (layer.type == LayerType.TEXT) {
            OutlinedButton(onClick = { editText = true }) { Text("Editar texto") }
            CommitSlider("Tamanho da fonte", layer.fontSize, 12f..400f) { actions.updateLayer(layer.copy(fontSize = it)) }
        }
        Text("Transformação e animação", style = MaterialTheme.typography.titleMedium)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            AnimatedProperty.entries.forEach { candidate ->
                FilterChip(selected = property == candidate, onClick = { property = candidate }, label = { Text(propertyLabel(candidate)) })
            }
        }
        val range = when (property) {
            AnimatedProperty.X -> -project.width.toFloat()..project.width * 2f
            AnimatedProperty.Y -> -project.height.toFloat()..project.height * 2f
            AnimatedProperty.SCALE_X, AnimatedProperty.SCALE_Y -> 0.05f..4f
            AnimatedProperty.ROTATION -> -360f..360f
            AnimatedProperty.OPACITY, AnimatedProperty.ANCHOR_X, AnimatedProperty.ANCHOR_Y -> 0f..1f
        }
        CommitSlider(propertyLabel(property), transform.value(property), range) { actions.setProperty(property, it) }
        PropertyNumberField(propertyLabel(property), transform.value(property)) { value ->
            val safe = if (property == AnimatedProperty.OPACITY) value.coerceIn(0f, 1f) else value.coerceIn(-100000f, 100000f)
            actions.setProperty(property, safe)
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilledTonalButton(onClick = { actions.toggleKeyframe(property, easing) }, enabled = atLayerTime) { Text(if (keyframe != null) "◆ Remover keyframe" else "◇ Criar keyframe") }
            Text("${track?.keyframes?.size ?: 0} pontos", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text(if (atLayerTime) "Altere o valor no tempo atual. Uma propriedade animada cria ou atualiza seu keyframe." else "Posicione o cursor dentro do intervalo da camada para animar.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Easing.entries.forEach { candidate ->
                FilterChip(selected = easing == candidate, onClick = {
                    easing = candidate
                    if (keyframe != null) actions.setKeyframeEasing(property, candidate)
                }, label = { Text(easingLabel(candidate)) })
            }
        }
        val curve = keyframe?.curve ?: BezierCurve()
        CurveGraph(easing, curve, keyframe != null && easing == Easing.CUBIC_BEZIER) { updated ->
            if (track != null && keyframe != null) {
                val tracks = layer.tracks.map { current ->
                    if (current.property != property) current else current.copy(keyframes = current.keyframes.map { point ->
                        if (point.timeMs == keyframe.timeMs) point.copy(easing = Easing.CUBIC_BEZIER, curve = updated) else point
                    })
                }
                actions.updateLayer(layer.copy(tracks = tracks))
            }
        }
        Text("A interpolação pertence ao keyframe inicial de cada segmento.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        HorizontalDivider()
        TimingEditor(project, layer, actions)
        SizeEditor(layer, actions)
    }
    if (rename) TextEntryDialog("Renomear camada", layer.name, { rename = false }, { actions.updateLayer(layer.copy(name = it)); rename = false })
    if (editText) TextEntryDialog("Texto da camada", layer.text, { editText = false }, { actions.updateLayer(layer.copy(text = it)); editText = false }, maxLength = 500)
}

@Composable
private fun CommitSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onCommit: (Float) -> Unit) {
    var draft by remember(value, label) { mutableFloatStateOf(value.coerceIn(range)) }
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, style = MaterialTheme.typography.labelMedium)
            Text(String.format(Locale.ROOT, "%.2f", draft), style = MaterialTheme.typography.labelMedium, color = Mint)
        }
        Slider(value = draft, onValueChange = { draft = it }, onValueChangeFinished = { onCommit(draft) }, valueRange = range, modifier = Modifier.semantics { contentDescription = label })
    }
}

@Composable
private fun PropertyNumberField(label: String, value: Float, onCommit: (Float) -> Unit) {
    var draft by remember(label, value) { mutableStateOf(String.format(Locale.ROOT, "%.2f", value)) }
    val parsed = draft.replace(',', '.').toFloatOrNull()?.takeIf { it.isFinite() }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedTextField(draft, { draft = it.take(16) }, label = { Text("Valor exato") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f))
        TextButton(enabled = parsed != null, onClick = { onCommit(parsed!!) }) { Text("Aplicar") }
    }
}

@Composable
private fun TimingEditor(project: MotionProject, layer: Layer, actions: StudioActions) {
    var start by remember(layer.id, layer.startMs) { mutableStateOf(formatSeconds(layer.startMs)) }
    var duration by remember(layer.id, layer.durationMs) { mutableStateOf(formatSeconds(layer.durationMs)) }
    val startValue = start.replace(',', '.').toDoubleOrNull()?.takeIf { it.isFinite() }?.let { (it * 1000).toLong() }
    val durationValue = duration.replace(',', '.').toDoubleOrNull()?.takeIf { it.isFinite() }?.let { (it * 1000).toLong() }
    val valid = startValue != null && durationValue != null && startValue >= 0 && durationValue >= 1 && startValue <= project.durationMs - durationValue
    Text("Intervalo da camada", style = MaterialTheme.typography.titleMedium)
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedTextField(start, { start = it.take(8) }, label = { Text("Início (s)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f))
        OutlinedTextField(duration, { duration = it.take(8) }, label = { Text("Duração (s)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f))
    }
    TextButton(enabled = valid, onClick = {
        val newDuration = durationValue!!
        actions.updateLayer(layer.copy(startMs = startValue!!, durationMs = newDuration, tracks = layer.tracks.map { it.copy(keyframes = it.keyframes.filter { key -> key.timeMs <= newDuration }) }))
    }) { Text("Aplicar intervalo") }
}

@Composable
private fun SizeEditor(layer: Layer, actions: StudioActions) {
    var width by remember(layer.id, layer.width) { mutableStateOf(layer.width.toInt().toString()) }
    var height by remember(layer.id, layer.height) { mutableStateOf(layer.height.toInt().toString()) }
    val w = width.toFloatOrNull()
    val h = height.toFloatOrNull()
    val valid = w != null && h != null && w in 1f..8192f && h in 1f..8192f
    Text("Dimensões da camada", style = MaterialTheme.typography.titleMedium)
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedTextField(width, { width = it.filter(Char::isDigit).take(4) }, label = { Text("Largura (px)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f))
        OutlinedTextField(height, { height = it.filter(Char::isDigit).take(4) }, label = { Text("Altura (px)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f))
    }
    TextButton(enabled = valid, onClick = { actions.updateLayer(layer.copy(width = w!!, height = h!!)) }) { Text("Aplicar tamanho") }
}

@Composable
private fun CurveGraph(easing: Easing, curve: BezierCurve, editable: Boolean, onCurveChange: (BezierCurve) -> Unit) {
    var draft by remember(curve, easing) { mutableStateOf(curve) }
    var handle by remember { mutableIntStateOf(0) }
    val latestCommit by rememberUpdatedState(onCurveChange)
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Canvas(Modifier.fillMaxWidth().height(112.dp).pointerInput(editable, curve, easing) {
            if (editable) detectDragGestures(
                onDragStart = { point ->
                    val normalized = Offset(point.x / size.width, 1f - point.y / size.height)
                    val d1 = abs(normalized.x - draft.x1) + abs(normalized.y - draft.y1)
                    val d2 = abs(normalized.x - draft.x2) + abs(normalized.y - draft.y2)
                    handle = if (d1 <= d2) 1 else 2
                },
                onDragEnd = { latestCommit(draft) },
                onDragCancel = { draft = curve },
            ) { change, _ ->
                change.consume()
                val x = (change.position.x / size.width).coerceIn(0f, 1f)
                val y = (1f - change.position.y / size.height).coerceIn(0f, 1f)
                draft = if (handle == 1) draft.copy(x1 = x, y1 = y) else draft.copy(x2 = x, y2 = y)
            }
        }.semantics { contentDescription = if (editable) "Curva Bézier; arraste os dois pontos de controle" else "Gráfico de interpolação" }) {
            for (step in 0..4) {
                val x = size.width * step / 4
                val y = size.height * step / 4
                drawLine(Color.White.copy(alpha = 0.08f), Offset(x, 0f), Offset(x, size.height))
                drawLine(Color.White.copy(alpha = 0.08f), Offset(0f, y), Offset(size.width, y))
            }
            val path = Path()
            for (i in 0..100) {
                val t = i / 100f
                val y = AnimationEngine.interpolate(t, easing, draft)
                if (i == 0) path.moveTo(0f, size.height * (1f - y)) else path.lineTo(t * size.width, size.height * (1f - y))
            }
            drawPath(path, Mint, style = Stroke(2.dp.toPx()))
            if (easing == Easing.CUBIC_BEZIER) {
                val first = Offset(draft.x1 * size.width, (1f - draft.y1) * size.height)
                val second = Offset(draft.x2 * size.width, (1f - draft.y2) * size.height)
                drawLine(Lilac.copy(alpha = 0.5f), Offset(0f, size.height), first, 1.dp.toPx())
                drawLine(Lilac.copy(alpha = 0.5f), Offset(size.width, 0f), second, 1.dp.toPx())
                drawCircle(Lilac, 6.dp.toPx(), first)
                drawCircle(Lilac, 6.dp.toPx(), second)
            }
        }
        Text(if (editable) "Bézier personalizada: arraste os pontos lilás." else "Valor ↑                         Tempo →", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

private fun propertyLabel(property: AnimatedProperty): String = when (property) {
    AnimatedProperty.X -> "Posição X"
    AnimatedProperty.Y -> "Posição Y"
    AnimatedProperty.SCALE_X -> "Escala X"
    AnimatedProperty.SCALE_Y -> "Escala Y"
    AnimatedProperty.ROTATION -> "Rotação"
    AnimatedProperty.OPACITY -> "Opacidade"
    AnimatedProperty.ANCHOR_X -> "Âncora X"
    AnimatedProperty.ANCHOR_Y -> "Âncora Y"
}

private fun easingLabel(easing: Easing): String = when (easing) {
    Easing.LINEAR -> "Linear"
    Easing.EASE_IN -> "Acelerar"
    Easing.EASE_OUT -> "Desacelerar"
    Easing.EASE_IN_OUT -> "Suave"
    Easing.HOLD -> "Manter"
    Easing.CUBIC_BEZIER -> "Bézier"
}
