// SPDX-License-Identifier: GPL-3.0-or-later
package org.openframe.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

internal val Palette = listOf(0xFF75E2C0L, 0xFFC5B6FFL, 0xFFFFB284L, 0xFF88BAFFL, 0xFFFF7799L, 0xFFFFFFFFL, 0xFF10131AL)

@Composable
internal fun ColorPicker(selected: Long, onSelect: (Long) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Palette.forEach { color ->
            Box(
                Modifier.size(42.dp)
                    .border(if (selected == color) 3.dp else 1.dp, if (selected == color) Color.White else Color.Gray, CircleShape)
                    .padding(5.dp)
                    .background(Color(color.toInt()), CircleShape)
                    .semantics { contentDescription = "Cor ${color.toString(16).uppercase()}" }
                    .clickable { onSelect(color) },
            )
        }
    }
}

@Composable
internal fun CreateProjectDialog(onDismiss: () -> Unit, onCreate: (String, Int, Int, Int, Long, Long) -> Unit) {
    var name by remember { mutableStateOf("Meu projeto") }
    var width by remember { mutableStateOf("1080") }
    var height by remember { mutableStateOf("1920") }
    var fps by remember { mutableIntStateOf(30) }
    var seconds by remember { mutableStateOf("5") }
    var background by remember { mutableLongStateOf(0xFF10131AL) }
    val widthValue = width.toIntOrNull()
    val heightValue = height.toIntOrNull()
    val durationValue = seconds.replace(',', '.').toDoubleOrNull()
    val valid = name.isNotBlank() && name.length <= 80 && widthValue != null && widthValue in 64..4096 && heightValue != null && heightValue in 64..4096 && durationValue != null && durationValue in 0.1..60.0
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nova composição") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(name, { name = it.take(80) }, label = { Text("Nome do projeto") }, singleLine = true, modifier = Modifier.fillMaxWidth().testTag("project_name"))
                Text("Formato", style = MaterialTheme.typography.labelLarge, color = Mint)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(1080 to 1920, 1920 to 1080, 1080 to 1080, 720 to 1280).forEach { (w, h) ->
                        FilterChip(selected = width == "$w" && height == "$h", onClick = { width = "$w"; height = "$h" }, label = { Text("$w × $h") })
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(width, { width = it.filter(Char::isDigit).take(4) }, label = { Text("Largura") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f))
                    OutlinedTextField(height, { height = it.filter(Char::isDigit).take(4) }, label = { Text("Altura") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f))
                }
                Text("64 a 4096 pixels por dimensão", style = MaterialTheme.typography.bodySmall)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(24, 25, 30, 60).forEach { rate ->
                        FilterChip(selected = fps == rate, onClick = { fps = rate }, label = { Text("$rate FPS") })
                    }
                }
                OutlinedTextField(seconds, { seconds = it.take(5) }, label = { Text("Duração em segundos") }, supportingText = { Text("0,1 a 60 segundos") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
                Text("Cor de fundo", style = MaterialTheme.typography.labelLarge)
                ColorPicker(background) { background = it }
            }
        },
        confirmButton = {
            Button(enabled = valid, onClick = { onCreate(name.trim(), widthValue!!, heightValue!!, fps, (durationValue!! * 1000).toLong(), background) }, modifier = Modifier.testTag("create_project")) { Text("Criar projeto") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )
}

@Composable
internal fun TextEntryDialog(title: String, initial: String, onDismiss: () -> Unit, onConfirm: (String) -> Unit, maxLength: Int = 80) {
    var text by remember(initial) { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(text, { text = it.take(maxLength) }, modifier = Modifier.fillMaxWidth(), label = { Text("Texto") }) },
        confirmButton = { Button(enabled = text.isNotBlank(), onClick = { onConfirm(text.trim()) }) { Text("Confirmar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )
}
