// SPDX-License-Identifier: GPL-3.0-or-later
package org.openframe.editor

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
internal fun AboutDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current.applicationContext
    var document by remember { mutableStateOf("NOTICE") }
    val license by produceState("Carregando…", document) {
        value = withContext(Dispatchers.IO) {
            runCatching { context.assets.open("licenses/$document").bufferedReader().use { it.readText() } }
                .getOrDefault("Não foi possível abrir os avisos de licença.")
        }
    }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("OpenFrame Motion 0.1.0") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Editor independente de código aberto. GPL-3.0-or-later.")
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                TextButton(onClick = { document = "NOTICE" }) { Text("Avisos") }
                TextButton(onClick = { document = "LICENSE" }) { Text("GPLv3") }
                TextButton(onClick = { document = "Apache-2.0.txt" }) { Text("Apache") }
            }
            Text(license, style = MaterialTheme.typography.bodySmall, modifier = Modifier.heightIn(max = 320.dp).verticalScroll(rememberScrollState()))
        }
    }, confirmButton = { TextButton(onClick = onDismiss) { Text("Fechar") } })
}
