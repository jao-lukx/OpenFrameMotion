// SPDX-License-Identifier: GPL-3.0-or-later
package org.openframe.editor

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.conflate
import kotlinx.coroutines.flow.collect
import org.openframe.animation.AnimationEngine
import org.openframe.model.Layer
import org.openframe.model.MotionProject
import org.openframe.rendering.CompositionRenderer
import java.io.File
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** A preview owns its renderer. Render and release serialize away from the UI thread. */
private data class PreviewFrame(val bitmap: Bitmap, val missingMedia: Boolean)
private data class PreviewRequest(val project: MotionProject, val timeMs: Long, val width: Int, val height: Int)

private class PreviewSession(mediaDirectory: File, thumbnail: Boolean) {
    private val lock = Any()
    private val renderer = CompositionRenderer(mediaDirectory,
        maxImageEdge = if (thumbnail) 256 else 1024,
        cacheBytes = if (thumbnail) 2 * 1024 * 1024 else 24 * 1024 * 1024)
    private var closed = false

    fun frame(project: MotionProject, time: Long, width: Int, height: Int): PreviewFrame = synchronized(lock) {
        check(!closed)
        val bitmap = renderer.renderBitmap(project, time, width, height)
        PreviewFrame(bitmap, renderer.missingMedia.isNotEmpty())
    }

    fun close() = synchronized(lock) {
        closed = true
        renderer.close()
    }
}

@Composable
internal fun ProjectPreview(
    project: MotionProject,
    timeMs: Long,
    mediaDirectory: File,
    modifier: Modifier = Modifier,
    selectedLayerId: String? = null,
    onSelect: ((String?) -> Unit)? = null,
    maxDimension: Int = 720,
) {
    val session = remember(project.id, mediaDirectory, maxDimension) { PreviewSession(mediaDirectory, maxDimension <= 256) }
    DisposableEffect(session) {
        onDispose { CoroutineScope(Dispatchers.Default).launch { session.close() } }
    }
    val longest = max(project.width, project.height).coerceAtLeast(1)
    val factor = min(1f, maxDimension.toFloat() / longest)
    val renderWidth = (project.width * factor).toInt().coerceAtLeast(1)
    val renderHeight = (project.height * factor).toInt().coerceAtLeast(1)
    val latestRequest by rememberUpdatedState(PreviewRequest(project, timeMs, renderWidth, renderHeight))
    // Finish the current frame and keep only the newest pending request. Cancelling
    // each in-flight frame would starve playback on devices slower than the frame rate.
    val frame by produceState<Result<PreviewFrame>?>(null, session) {
        snapshotFlow { latestRequest }.conflate().collect { request ->
            value = withContext(Dispatchers.Default) {
                runCatching { session.frame(request.project, request.timeMs, request.width, request.height) }
            }
        }
    }
    Box(modifier.semantics { contentDescription = "Pré-visualização da composição" }, contentAlignment = Alignment.Center) {
        frame?.getOrNull()?.let { rendered ->
            Image(rendered.bitmap.asImageBitmap(), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
            if (rendered.missingMedia) Text("Mídia indisponível", color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.labelSmall, modifier = Modifier.align(Alignment.BottomCenter).padding(6.dp))
        }
        if (frame?.isFailure == true) {
            Text("Não foi possível renderizar este quadro", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(12.dp))
        }
        if (onSelect != null) {
            Canvas(Modifier.fillMaxSize().pointerInput(project, timeMs) {
                detectTapGestures { tap ->
                    val scale = min(size.width.toFloat() / project.width, size.height.toFloat() / project.height)
                    val x = (tap.x - (size.width - project.width * scale) / 2f) / scale
                    val y = (tap.y - (size.height - project.height * scale) / 2f) / scale
                    val hit = project.layers.asReversed().firstOrNull { layer -> layer.isActive(timeMs) && hitTest(layer, timeMs, x, y) }
                    onSelect(hit?.id)
                }
            }) {
                val layer = project.layers.firstOrNull { it.id == selectedLayerId && it.isActive(timeMs) }
                if (layer != null) {
                    val transform = AnimationEngine.evaluate(layer, timeMs)
                    val scale = min(size.width / project.width, size.height / project.height)
                    val left = (size.width - project.width * scale) / 2f
                    val top = (size.height - project.height * scale) / 2f
                    val angle = Math.toRadians(transform.rotation.toDouble())
                    val c = cos(angle).toFloat()
                    val s = sin(angle).toFloat()
                    fun point(x: Float, y: Float): Offset {
                        val px = (x - layer.width * transform.anchorX) * transform.scaleX
                        val py = (y - layer.height * transform.anchorY) * transform.scaleY
                        return Offset(left + (transform.x + px * c - py * s) * scale, top + (transform.y + px * s + py * c) * scale)
                    }
                    val corners = listOf(point(0f, 0f), point(layer.width, 0f), point(layer.width, layer.height), point(0f, layer.height))
                    val outline = Path().apply {
                        moveTo(corners[0].x, corners[0].y)
                        corners.drop(1).forEach { lineTo(it.x, it.y) }
                        close()
                    }
                    drawPath(outline, Mint, style = Stroke(1.5.dp.toPx()))
                    corners.forEach { drawCircle(Mint, 3.dp.toPx(), it) }
                }
            }
        }
    }
}

private fun hitTest(layer: Layer, timeMs: Long, x: Float, y: Float): Boolean {
    val transform = AnimationEngine.evaluate(layer, timeMs)
    if (transform.opacity <= 0f || transform.scaleX == 0f || transform.scaleY == 0f) return false
    val angle = Math.toRadians(-transform.rotation.toDouble())
    val dx = x - transform.x
    val dy = y - transform.y
    val localX = (dx * cos(angle) - dy * sin(angle)).toFloat() / transform.scaleX + layer.width * transform.anchorX
    val localY = (dx * sin(angle) + dy * cos(angle)).toFloat() / transform.scaleY + layer.height * transform.anchorY
    return localX in 0f..layer.width && localY in 0f..layer.height
}
