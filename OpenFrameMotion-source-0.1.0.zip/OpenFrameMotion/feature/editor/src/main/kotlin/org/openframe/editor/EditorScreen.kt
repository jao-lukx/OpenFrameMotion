// SPDX-License-Identifier: GPL-3.0-or-later
package org.openframe.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import org.openframe.model.ShapeKind
import java.io.File

@Composable
internal fun EditorScreen(state: StudioState, actions: StudioActions, mediaDirectory: File) {
    val project = state.project ?: return
    var adding by remember { mutableStateOf(false) }
    var addingText by remember { mutableStateOf(false) }
    var exportConfirmation by remember { mutableStateOf(false) }
    val previewHeight = (LocalConfiguration.current.screenHeightDp * 0.3f).coerceIn(180f, 280f).dp
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = actions::closeProject, contentPadding = PaddingValues(horizontal = 8.dp), modifier = Modifier.testTag("back_projects")) { Text("‹ Projetos") }
            Column(Modifier.weight(1f).padding(horizontal = 4.dp)) {
                Text(project.name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleSmall)
                Text(state.saveStatus, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            TextButton(onClick = { exportConfirmation = true }, enabled = !state.busy) { Text("Exportar") }
        }
        if (state.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 30.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Box(Modifier.fillMaxWidth().height(previewHeight).background(CanvasBackground).padding(10.dp), contentAlignment = Alignment.Center) {
                    ProjectPreview(project, state.playheadMs, mediaDirectory, Modifier.fillMaxSize(), state.selectedLayerId, actions::selectLayer)
                }
                Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("${project.width} × ${project.height} · ${project.fps} FPS", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("Toque para selecionar", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            item {
                Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        FilledTonalButton(onClick = actions::togglePlayback, enabled = !state.busy, modifier = Modifier.weight(1f).testTag("play_pause")) { Text(if (state.playing) "Ⅱ Pausar" else "▶ Reproduzir") }
                        Button(onClick = { adding = true }, enabled = !state.busy && project.layers.size < 64, modifier = Modifier.weight(1f).testTag("add_layer")) { Text("+ Camada") }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = actions::undo, enabled = state.canUndo && !state.busy, modifier = Modifier.testTag("undo")) { Text("↶ Desfazer") }
                        TextButton(onClick = actions::redo, enabled = state.canRedo && !state.busy, modifier = Modifier.testTag("redo")) { Text("↷ Refazer") }
                        TextButton(onClick = actions::save, modifier = Modifier.testTag("save_project")) { Text("Salvar") }
                    }
                }
            }
            item { Timeline(project, state, actions) }
            item {
                val selected = state.selectedLayer
                if (selected != null) {
                    LayerProperties(project, selected, state.playheadMs, actions)
                } else {
                    Column(Modifier.fillMaxWidth().padding(22.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Sua composição, quadro a quadro", style = MaterialTheme.typography.titleMedium)
                        Text("Adicione formas, texto ou uma imagem. Selecione uma camada para ajustar suas propriedades e animar com keyframes.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
    if (adding) {
        AlertDialog(onDismissRequest = { adding = false }, title = { Text("Adicionar camada") }, text = {
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { adding = false; actions.addShape(ShapeKind.RECTANGLE) }, modifier = Modifier.fillMaxWidth().testTag("add_rectangle")) { Text("▭  Retângulo") }
                OutlinedButton(onClick = { adding = false; actions.addShape(ShapeKind.ELLIPSE) }, modifier = Modifier.fillMaxWidth()) { Text("◯  Elipse") }
                OutlinedButton(onClick = { adding = false; addingText = true }, modifier = Modifier.fillMaxWidth()) { Text("T  Texto") }
                OutlinedButton(onClick = { adding = false; actions.importImage() }, modifier = Modifier.fillMaxWidth()) { Text("▧  Imagem do dispositivo") }
            }
        }, confirmButton = { TextButton(onClick = { adding = false }) { Text("Fechar") } })
    }
    if (addingText) TextEntryDialog("Adicionar texto", "OpenFrame", { addingText = false }, { text -> addingText = false; actions.addText(text) }, maxLength = 500)
    if (exportConfirmation) {
        AlertDialog(onDismissRequest = { exportConfirmation = false }, title = { Text("Exportar vídeo") }, text = {
            Text("A composição será renderizada em MP4/H.264, sem marca-d’água e sem áudio. A resolução de saída é reduzida para até 720p nesta versão. Você escolherá onde salvar o arquivo.")
        }, confirmButton = { Button(onClick = { exportConfirmation = false; actions.exportVideo() }) { Text("Escolher destino") } }, dismissButton = { TextButton(onClick = { exportConfirmation = false }) { Text("Cancelar") } })
    }
}
