// SPDX-License-Identifier: GPL-3.0-or-later
package org.openframe.editor

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.io.File

@Composable
fun OpenFrameApp(state: StudioState, actions: StudioActions, mediaDirectory: File) {
    OpenFrameTheme {
        val snackbar = remember { SnackbarHostState() }
        LaunchedEffect(state.message) {
            state.message?.let { message ->
                snackbar.showSnackbar(message, duration = SnackbarDuration.Long)
                actions.dismissMessage()
            }
        }
        BackHandler(enabled = state.project != null && state.exportProgress == null) {
            actions.closeProject()
        }
        Scaffold(
            snackbarHost = { SnackbarHost(snackbar) },
            contentWindowInsets = WindowInsets.safeDrawing,
        ) { insets ->
            Surface(Modifier.fillMaxSize().padding(insets)) {
                if (state.project == null) {
                    ProjectsScreen(state, actions, mediaDirectory)
                } else {
                    EditorScreen(state, actions, mediaDirectory)
                }
            }
        }
        if (state.exportProgress != null) {
            AlertDialog(
                onDismissRequest = {},
                title = { Text("Exportando composição") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        Text("MP4 · H.264 · sem áudio\nMantenha o aplicativo aberto.")
                        LinearProgressIndicator(
                            progress = { state.exportProgress.coerceIn(0f, 1f) },
                            modifier = Modifier.fillMaxWidth(),
                        )
                        Text("${(state.exportProgress * 100).toInt()}%")
                    }
                },
                confirmButton = {
                    TextButton(onClick = actions::cancelExport) { Text("Cancelar exportação") }
                },
            )
        }
    }
}
