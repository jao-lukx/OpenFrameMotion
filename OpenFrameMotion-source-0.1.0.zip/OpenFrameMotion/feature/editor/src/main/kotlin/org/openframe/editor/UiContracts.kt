// SPDX-License-Identifier: GPL-3.0-or-later
package org.openframe.editor

import org.openframe.model.*

data class StudioState(
    val projects: List<MotionProject> = emptyList(),
    val project: MotionProject? = null,
    val selectedLayerId: String? = null,
    val playheadMs: Long = 0,
    val playing: Boolean = false,
    val canUndo: Boolean = false,
    val canRedo: Boolean = false,
    val busy: Boolean = false,
    val saveStatus: String = "Salvo",
    val message: String? = null,
    val exportProgress: Float? = null,
) {
    val selectedLayer: Layer? get() = project?.layers?.firstOrNull { it.id == selectedLayerId }
}

interface StudioActions {
    fun createProject(name: String, width: Int, height: Int, fps: Int, durationMs: Long, backgroundColor: Long)
    fun openProject(id: String)
    fun closeProject()
    fun renameProject(id: String, name: String)
    fun duplicateProject(id: String)
    fun deleteProject(id: String)
    fun addShape(shape: ShapeKind)
    fun addText(text: String)
    fun importImage()
    fun selectLayer(id: String?)
    fun updateLayer(layer: Layer)
    fun deleteSelectedLayer()
    fun duplicateSelectedLayer()
    fun moveSelectedLayer(direction: Int)
    fun setProperty(property: AnimatedProperty, value: Float)
    fun toggleKeyframe(property: AnimatedProperty, easing: Easing)
    fun setKeyframeEasing(property: AnimatedProperty, easing: Easing)
    fun seek(timeMs: Long)
    fun togglePlayback()
    fun undo()
    fun redo()
    fun save()
    fun exportVideo()
    fun cancelExport()
    fun dismissMessage()
}
