// SPDX-License-Identifier: GPL-3.0-or-later
package org.openframe.editor

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import org.openframe.model.MotionProject
import java.io.File

@Composable
internal fun ProjectsScreen(state: StudioState, actions: StudioActions, mediaDirectory: File) {
    var creating by remember { mutableStateOf(false) }
    var renaming by remember { mutableStateOf<MotionProject?>(null) }
    var deleting by remember { mutableStateOf<MotionProject?>(null) }
    var about by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 24.dp, bottom = 24.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Canvas(Modifier.size(42.dp)) {
                drawRect(Lilac, Offset(size.width * 0.25f, 0f), Size(size.width * 0.75f, size.height * 0.75f), style = Stroke(3.dp.toPx()))
                drawRect(Mint, Offset(0f, size.height * 0.25f), Size(size.width * 0.75f, size.height * 0.75f), style = Stroke(3.dp.toPx()))
            }
            Column {
                Text("OpenFrame", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text("MOTION · CRIAÇÃO LIVRE", style = MaterialTheme.typography.labelSmall, color = Mint)
            }
        }
        Row(Modifier.fillMaxWidth().padding(bottom = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Seus projetos", style = MaterialTheme.typography.titleLarge)
                Text("${state.projects.size} composições neste dispositivo", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            TextButton(onClick = { about = true }) { Text("Sobre") }
        }
        Button(onClick = { creating = true }, enabled = !state.busy, modifier = Modifier.fillMaxWidth().height(52.dp).testTag("new_project"), shape = RoundedCornerShape(14.dp)) {
            Text("+  Novo projeto", style = MaterialTheme.typography.titleSmall)
        }
        if (state.busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 12.dp))
        if (state.projects.isEmpty()) {
            Column(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Uma ideia. Muitas camadas.", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(12.dp))
                Text("Crie sua primeira composição com formas,\ntexto, imagens e animações por keyframes.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(24.dp))
                Text("Offline · Sem marca-d’água · Código aberto", color = Mint, style = MaterialTheme.typography.labelMedium)
            }
        } else {
            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(top = 20.dp, bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(state.projects, key = { it.id }) { project ->
                    ProjectCard(project, mediaDirectory,
                        onOpen = { actions.openProject(project.id) },
                        onRename = { renaming = project },
                        onDuplicate = { actions.duplicateProject(project.id) },
                        onDelete = { deleting = project },
                    )
                }
                item { Text("Projetos e mídias ficam no armazenamento privado do aplicativo.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp)) }
            }
        }
    }
    if (about) AboutDialog { about = false }
    if (creating) CreateProjectDialog(onDismiss = { creating = false }) { name, width, height, fps, duration, color ->
        creating = false
        actions.createProject(name, width, height, fps, duration, color)
    }
    renaming?.let { project ->
        TextEntryDialog("Renomear projeto", project.name, { renaming = null }, { name ->
            actions.renameProject(project.id, name)
            renaming = null
        })
    }
    deleting?.let { project ->
        AlertDialog(onDismissRequest = { deleting = null }, title = { Text("Excluir projeto?") }, text = { Text("“${project.name}” será removido deste dispositivo. Esta ação não pode ser desfeita.") },
            confirmButton = { TextButton(onClick = { actions.deleteProject(project.id); deleting = null }) { Text("Excluir", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancelar") } },
        )
    }
}

@Composable
private fun ProjectCard(project: MotionProject, mediaDirectory: File, onOpen: () -> Unit, onRename: () -> Unit, onDuplicate: () -> Unit, onDelete: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    Surface(shape = RoundedCornerShape(16.dp), tonalElevation = 2.dp, modifier = Modifier.fillMaxWidth().testTag("project_${project.id}").clickable(onClick = onOpen)) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            ProjectPreview(project, 0, mediaDirectory, Modifier.size(82.dp).clip(RoundedCornerShape(10.dp)).background(CanvasBackground), maxDimension = 180)
            Column(Modifier.weight(1f).padding(start = 14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(project.name, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleMedium)
                Text("${project.width} × ${project.height} · ${project.fps} FPS", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("${formatSeconds(project.durationMs)} s · ${project.layers.size} camadas", style = MaterialTheme.typography.labelSmall, color = Mint)
            }
            Box {
                TextButton(onClick = { menu = true }, contentPadding = PaddingValues(0.dp), modifier = Modifier.width(44.dp)) { Text("•••") }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Renomear") }, onClick = { menu = false; onRename() })
                    DropdownMenuItem(text = { Text("Duplicar") }, onClick = { menu = false; onDuplicate() })
                    DropdownMenuItem(text = { Text("Excluir") }, onClick = { menu = false; onDelete() })
                }
            }
        }
    }
}
