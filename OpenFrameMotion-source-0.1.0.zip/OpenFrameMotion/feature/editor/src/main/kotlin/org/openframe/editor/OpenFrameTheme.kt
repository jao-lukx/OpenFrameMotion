// SPDX-License-Identifier: GPL-3.0-or-later
package org.openframe.editor

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

internal val Mint = Color(0xFF75E2C0)
internal val Lilac = Color(0xFFC5B6FF)
internal val Panel = Color(0xFF171C26)
internal val CanvasBackground = Color(0xFF0B0F16)

@Composable
internal fun OpenFrameTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Mint,
            onPrimary = Color(0xFF00382D),
            secondary = Lilac,
            onSecondary = Color(0xFF302351),
            background = CanvasBackground,
            surface = Panel,
            surfaceVariant = Color(0xFF252D3B),
            onBackground = Color(0xFFE9EEF7),
            onSurface = Color(0xFFE9EEF7),
            onSurfaceVariant = Color(0xFFB0BACB),
            outline = Color(0xFF485367),
        ),
        content = content,
    )
}
