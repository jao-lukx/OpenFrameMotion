# OpenFrame Motion

Editor Android nativo de animação 2D e motion graphics, com Kotlin e Jetpack Compose. Projeto independente, gratuito e licenciado sob **GPL-3.0-or-later**. Não contém código, logotipos ou recursos do Alight Motion.

Esta é a base incremental **0.1**, não uma implementação de paridade. O estado comprovado da compilação, dos testes e do APK está em [docs/TEST-REPORT.md](docs/TEST-REPORT.md). A existência do código de uma funcionalidade não significa que ela tenha sido validada em aparelho.

## Escopo desta versão

- Projetos locais com nome, resolução, FPS, fundo e duração; formato JSON versionado.
- Camadas de formas, texto e imagens; ordem, visibilidade, duração e transformações.
- Timeline, preview da composição, reprodução, seleção e histórico básico.
- Motor de keyframes independente da UI: posição, escala, rotação, opacidade e âncora; linear, ease, hold e Bézier.
- Pipeline separado de MP4/H.264 para a composição visual, sem áudio e sem marca-d'água. A disponibilidade depende do encoder do aparelho; a validação está no relatório de testes.

Vídeo e áudio como camadas, editor gráfico completo de curvas, máscaras, grupos, efeitos GPU e importação de XML de terceiros permanecem pendentes. Há um editor Bézier básico por toque, sem gráfico de velocidade. A renderização inicial usa Canvas; o uso de EGL no encoder não equivale a um motor completo de efeitos GPU.

## Compilar

Requisitos: JDK 17, Python 3.9+, Android SDK Platform 36 e Build Tools 35.0.0. Android mínimo: 8.0/API 26. O `gradlew` desta entrega usa um bootstrap em código-fonte que baixa Gradle 8.13 oficial e verifica seu SHA-256; não inclui `gradle-wrapper.jar`. A primeira resolução de Gradle e dependências precisa de rede; a edição no aplicativo não exige rede.

```sh
export JAVA_HOME=/caminho/para/jdk17
export ANDROID_HOME=/caminho/para/android-sdk
./gradlew assembleDebug
```

Depois de uma compilação bem-sucedida, o APK é escrito em `app/build/outputs/apk/debug/app-debug.apk`.

```sh
./gradlew :core:model:test :core:animation:test :core:persistence:test lintDebug
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

Abra a pasta raiz no Android Studio para importar o projeto Gradle. Veja o [guia para Arch Linux](docs/BUILD-ARCH-LINUX.md) e o [plano de testes](docs/TEST-PLAN.md).

## Estrutura

| Módulo | Responsabilidade |
| --- | --- |
| `app` | Activity, estado do editor, operações de usuário e armazenamento Android |
| `core/model` | Modelo imutável, versão do formato e validação |
| `core/animation` | Avaliação temporal e matemática de interpolação |
| `core/persistence` | Codec JSON, gravação atômica e recuperação |
| `core/rendering` | Composição visual de formas, texto e imagens |
| `feature/editor` | Tela de projetos, preview, timeline e propriedades Compose |
| `feature/export` | Encoding MP4 com MediaCodec/MediaMuxer e EGL |

Não há módulos vazios para funcionalidades futuras. Os limites iniciais são 64 camadas, 60 segundos, dimensões de 64 a 4096 pixels e até 256 keyframes por trilha. Esses limites evitam projetos descontrolados; não são garantia de fluidez em todos os dispositivos.

## Documentação

- [Arquitetura e evolução do renderizador](docs/ARCHITECTURE.md)
- [Formato de projetos](docs/PROJECT-FORMAT.md)
- [Pesquisa técnica e versões fixadas](docs/TECHNICAL-RESEARCH.md)
- [Decisões técnicas](docs/DECISIONS.md)
- [Roadmap e pendências](docs/ROADMAP.md)
- [Licenças e inventário de dependências](docs/LICENSES.md)
- [Contribuir](CONTRIBUTING.md) e [relatar problemas de segurança](SECURITY.md)

O repositório está preparado para publicação no GitHub, mas nenhum endereço público é presumido. Os workflows geram artefatos após execução; não há link fictício de download nem release automático com chave de produção.

## Licença

Copyright © 2026 colaboradores do OpenFrame Motion. Você pode redistribuir e modificar o código sob a GNU General Public License, versão 3 ou posterior. O programa é fornecido sem garantia. Veja [LICENSE](LICENSE), [NOTICE](NOTICE) e o escopo da [revisão de dependências](docs/LICENSES.md). Ao distribuir um APK, disponibilize também seu código-fonte correspondente, os scripts de build e os avisos aplicáveis.
