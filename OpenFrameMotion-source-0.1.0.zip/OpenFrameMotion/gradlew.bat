@echo off
rem SPDX-License-Identifier: GPL-3.0-or-later
python "%~dp0scripts\gradle_bootstrap.py" %*
exit /b %ERRORLEVEL%
