pluginManagement {
    repositories { google(); mavenCentral(); gradlePluginPortal() }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories { google(); mavenCentral() }
}
rootProject.name = "OpenFrameMotion"
include(":app", ":core:model", ":core:animation", ":core:persistence", ":core:rendering", ":feature:editor", ":feature:export")
