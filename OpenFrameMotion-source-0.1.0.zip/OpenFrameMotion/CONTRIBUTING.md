# Contribuir com OpenFrame Motion

Contribuições devem preservar um aplicativo Android compilável, com comportamento observável e recursos honestamente descritos. Envie mudanças pequenas, com problema, comportamento resultante e evidência de validação.

## Preparação

1. Leia [arquitetura](docs/ARCHITECTURE.md), [contratos](docs/INTERFACES.md) e [decisões](docs/DECISIONS.md).
2. Configure JDK 17 e SDK conforme [guia de build](docs/BUILD-ARCH-LINUX.md).
3. Execute os testes relevantes e `./gradlew assembleDebug lintDebug`.
4. Para mudanças de renderização/exportação, execute os testes Android e compare frames exportados com o preview.

## Regras de contribuição

- Kotlin, código de UI em Compose e Gradle Kotlin DSL. Modelos e matemática ficam sem dependências Android.
- Mantenha IDs persistentes, unidades de tempo em milissegundos no modelo e limites documentados.
- Não adicione botões sem comportamento implementado. Recursos incompletos ficam no roadmap.
- Teste invariantes, erros e regressões; não apenas linhas ou detalhes internos.
- I/O e encoding ficam fora da thread principal. Libere bitmaps, codecs, surfaces e contextos EGL.
- Mudanças de schema exigem estratégia explícita de migração, fixtures antigas e testes de abertura/recuperação.
- Cada dependência nova precisa de justificativa, versão fixa, origem e licença verificada.
- Não aceite código, assets ou fontes extraídos de produtos proprietários. Conteúdo de exemplo deve ser original ou acompanhado de licença compatível.
- Não inclua credenciais, keystores, mídias pessoais, SDKs ou artefatos de build no Git.

## Licenciamento

Ao contribuir, você confirma que pode licenciar sua contribuição sob GPL-3.0-or-later. Preserve avisos de terceiros. Use `SPDX-License-Identifier: GPL-3.0-or-later` em novos arquivos de código originais. Documente exceções de licença quando forem necessárias; dependências permanecem sob suas próprias licenças.

## Revisão e relato

Um PR deve explicar o problema concreto, a mudança e os testes efetivamente executados. Identifique o aparelho/API/encoder quando relevantes. Não marque testes não executados como aprovados. Relatos de problemas devem incluir passos mínimos e projeto sintético sem conteúdo privado.

O mantenedor decide quando publicar releases e como assinar APKs de produção. A CI produz APK debug para testes; a chave debug não é uma identidade de distribuição estável.
