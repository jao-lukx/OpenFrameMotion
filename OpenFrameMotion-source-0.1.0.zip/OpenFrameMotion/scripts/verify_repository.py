#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Offline repository integrity checks. This is NOT a Kotlin compiler or Android test."""
import ast
from pathlib import Path
import re
import sys
import tomllib
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[1]
failures = []


def check(condition, message):
    if not condition:
        failures.append(message)


def sources(pattern):
    excluded = {".gradle", ".git", ".kotlin", "build"}
    return [path for path in root.rglob(pattern) if not excluded.intersection(path.relative_to(root).parts)]


settings = (root / "settings.gradle.kts").read_text()
modules = re.findall(r'"(:[a-z:]+)"', settings)
catalog = tomllib.loads((root / "gradle/libs.versions.toml").read_text())
aliases = {".".join(name.split("-")) for name in catalog["libraries"]}
plugin_aliases = {".".join(name.split("-")) for name in catalog["plugins"]}
for name in modules:
    folder = root / name[1:].replace(":", "/")
    check((folder / "build.gradle.kts").is_file(), f"Missing build script: {name}")
    check(any((folder / "src/main").rglob("*.kt")), f"Empty source module: {name}")
for path in sources("*.gradle.kts"):
    content = path.read_text()
    for alias in re.findall(r"libs\.plugins\.([a-zA-Z0-9.]+)", content):
        check(alias in plugin_aliases, f"Unknown plugin alias {alias}: {path.relative_to(root)}")
    for alias in re.findall(r"libs\.([a-zA-Z0-9.]+)", content):
        if not alias.startswith("plugins."):
            check(alias in aliases, f"Unknown library alias {alias}: {path.relative_to(root)}")
    for dependency in re.findall(r'project\("(:[a-z:]+)"\)', content):
        check(dependency in modules, f"Unknown module {dependency}")
xml_files = sources("*.xml")
for path in xml_files:
    try:
        ET.parse(path)
    except ET.ParseError as error:
        failures.append(f"Invalid XML {path}: {error}")
for path in sources("*.md"):
    for target in re.findall(r"\]\(([^)]+)\)", path.read_text()):
        target = target.split("#")[0]
        if not target or "://" in target or target.startswith("mailto:"):
            continue
        check((path.parent / target).exists(), f"Broken document link {path.relative_to(root)} -> {target}")
for original, asset in [("LICENSE", "LICENSE"), ("NOTICE", "NOTICE"), ("licenses/Apache-2.0.txt", "Apache-2.0.txt")]:
    copy = root / "app/src/main/assets/licenses" / asset
    check(copy.is_file() and copy.read_bytes() == (root / original).read_bytes(), f"License asset differs: {asset}")
for path in (root / "scripts").glob("*.py"):
    ast.parse(path.read_text(), filename=str(path))
kotlin_files = sources("*.kt")
unit_tests = sum(len(re.findall(r"@Test\b", path.read_text())) for path in kotlin_files if "/src/test/" in str(path))
device_tests = sum(len(re.findall(r"@Test\b", path.read_text())) for path in kotlin_files if "/src/androidTest/" in str(path))
check("distributionSha256Sum=" in (root / "gradle/wrapper/gradle-wrapper.properties").read_text(), "Missing Gradle checksum")
print(f"Modules: {len(modules)}; Kotlin files: {len(kotlin_files)}; XML files parsed: {len(xml_files)}")
print(f"JUnit tests found, NOT executed: {unit_tests} JVM + {device_tests} Android")
if failures:
    print("\n".join(failures), file=sys.stderr)
    sys.exit(1)
print("PASS: repository structure, aliases, XML, document links, license assets and Python syntax")
print("Kotlin compilation, lint, Android runtime and codec validation still require the Android toolchain.")
