# Segurança

OpenFrame Motion é um editor local. O fluxo principal não precisa de conta, acesso amplo ao armazenamento, microfone ou rede. Mídias devem entrar pelo seletor de documentos do Android e ser validadas antes do uso.

## Escopo atual

- JSON versionado com limites de tamanho/estrutura, IDs e referências de mídia restritos.
- Arquivos de projeto e mídias importadas armazenados no diretório privado do aplicativo.
- Falhas de decodificação e codecs devem aparecer como erros recuperáveis.
- A exportação usa APIs e codecs do sistema Android; mantenha o sistema atualizado.
- Conteúdos de projeto podem incluir texto e referências a arquivos pessoais. Não publique projetos de usuários em issues.

## Relatar vulnerabilidades

Ainda não há um repositório público ou canal privado de segurança configurado. Ao publicar o repositório, o mantenedor deve habilitar **GitHub Private vulnerability reporting** e atualizar este arquivo com o canal confirmado.

Quando esse canal existir, envie versão/commit, API Android, passos de reprodução, impacto e exemplo mínimo sem dados pessoais. Não publique credenciais, arquivos privados ou demonstrações destrutivas em issues públicas.

Não há SLA de correção nem auditoria independente declarada. A revisão de código e os testes iniciais não constituem certificação de segurança. Bugs comuns sem impacto de segurança podem ser enviados ao issue tracker quando estiver disponível.
