# Licenças e inventário inicial

Código original: **GPL-3.0-or-later**, texto integral em `LICENSE`. Não foi usado código proprietário do Alight Motion. A fonte tipográfica vem do sistema Android, sem arquivo de fonte redistribuído. O ícone vetorial é original.

| Dependência | Versão | Licença declarada pelo projeto |
| --- | --- | --- |
| Kotlin e plugins Kotlin | 2.2.21 | Apache-2.0 |
| kotlinx.coroutines | 1.10.2 | Apache-2.0 |
| kotlinx.serialization | 1.9.0 | Apache-2.0 |
| AndroidX Compose UI/Foundation/Material3 | BOM 2025.10.01 | Apache-2.0 |
| AndroidX Activity | 1.11.0 | Apache-2.0 |
| AndroidX Lifecycle | 2.9.4 | Apache-2.0 |
| AndroidX ExifInterface | 1.4.1 | Apache-2.0 |
| AndroidX Test runner/ext-junit | 1.7.0 / 1.3.0 | Apache-2.0; apenas testes |
| JUnit | 4.13.2 | EPL-1.0; apenas testes, não incluído no APK |
| Android Gradle Plugin | 8.13.2 | Apache-2.0; build |
| Gradle | 8.13 | Apache-2.0 e avisos das dependências da distribuição; build |

Fontes oficiais: [AndroidX](https://android.googlesource.com/platform/frameworks/support/+/androidx-main/LICENSE.txt), [Kotlin](https://github.com/JetBrains/kotlin/blob/master/license/LICENSE.txt), [coroutines](https://github.com/Kotlin/kotlinx.coroutines/blob/master/LICENSE.txt), [serialization](https://github.com/Kotlin/kotlinx.serialization/blob/master/LICENSE.txt), [JUnit](https://github.com/junit-team/junit4/blob/main/LICENSE-junit.txt) e [Gradle](https://github.com/gradle/gradle/blob/master/LICENSE).

A Apache-2.0 é compatível com GPLv3 segundo a [lista de licenças da FSF](https://www.gnu.org/licenses/license-list.en.html#apache2). A opção GPL-3.0-or-later aplica-se ao código original; não relicencia bibliotecas de terceiros. Ferramentas de SDK/JDK e codecs fornecidos pelo Android têm suas próprias condições e não são distribuídos neste pacote de fontes.

## Limite da verificação nesta sessão

A resolução Gradle foi bloqueada pela rede antes de baixar o grafo. Portanto esta é uma revisão **das dependências diretas declaradas**, não uma auditoria concluída de todos os JARs/AARs transitivos. Não há APK nem binários de terceiros neste pacote. `LICENSE`, `NOTICE` e o texto Apache-2.0 acompanham o projeto e os assets do aplicativo, acessíveis pela tela Sobre.

Antes de distribuir uma release binária, executar `./gradlew :app:dependencies --configuration debugRuntimeClasspath`, preservar o relatório, extrair e revisar LICENSE/NOTICE de cada artefato resolvido e incluir seus avisos exatos em `app/src/main/assets/licenses/NOTICE`. Auditar também o classpath release se ele divergir. Publicar o código-fonte correspondente ao commit usado e os scripts de build junto do APK. Não redistribuir o cache Gradle inteiro como parte do aplicativo.
