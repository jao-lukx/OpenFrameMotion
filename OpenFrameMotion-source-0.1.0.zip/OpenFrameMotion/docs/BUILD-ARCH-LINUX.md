# Compilar no Arch Linux

Este guia prepara ferramentas locais. Não pressupõe que elas já estejam instaladas nem que um APK tenha sido produzido nesta sessão. Veja [TEST-REPORT.md](TEST-REPORT.md).

## 1. JDK e ferramentas

```sh
sudo pacman -Syu --needed jdk17-openjdk git unzip python
export JAVA_HOME=/usr/lib/jvm/java-17-openjdk
export PATH="$JAVA_HOME/bin:$PATH"
java -version
javac -version
```

O projeto fixa Gradle 8.13. Nesta entrega, `gradlew` usa um bootstrap em Python 3.9+ que baixa a distribuição oficial, confere SHA-256 fixo e a executa. Não inclui `gradle-wrapper.jar`: a rede do ambiente impediu obter esse binário. Não é necessário instalar o pacote `gradle` do Arch, que pode apontar para outra versão. `java` sem `javac` indica que a instalação pode não conter os executáveis de desenvolvimento.

## 2. Android SDK

Instale Android Studio ou obtenha as **Command line tools only — Linux** na [página oficial](https://developer.android.com/studio#command-line-tools-only). Confira o checksum publicado para o arquivo escolhido. SDK e emulador têm termos de distribuição próprios; não são copiados para este repositório.

Defina um diretório gravável:

```sh
export ANDROID_HOME="$HOME/Android/Sdk"
mkdir -p "$ANDROID_HOME/cmdline-tools"
```

Extraia o ZIP em uma pasta temporária. Mova a pasta extraída `cmdline-tools` para `$ANDROID_HOME/cmdline-tools/latest`. O caminho final do executável deve ser `$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager` (sem um segundo `cmdline-tools` dentro de `latest`).

```sh
export PATH="$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$PATH"
sdkmanager --licenses
sdkmanager 'platform-tools' 'platforms;android-36' 'build-tools;35.0.0'
```

Leia e aceite os termos do SDK. As dependências Gradle vêm de Google Maven, Maven Central e do portal de plugins Gradle. Uma falha de proxy ou DNS deve ser resolvida no ambiente; não desative a verificação TLS.

## 3. Compilar e testar

No diretório que contém `settings.gradle.kts`:

```sh
chmod +x gradlew
./gradlew --version
./gradlew :core:model:test :core:animation:test :core:persistence:test
./gradlew lintDebug
./gradlew assembleDebug
```

O arquivo esperado após sucesso é `app/build/outputs/apk/debug/app-debug.apk`. Para verificar o conteúdo e a assinatura debug:

```sh
test -s app/build/outputs/apk/debug/app-debug.apk
unzip -t app/build/outputs/apk/debug/app-debug.apk
"$ANDROID_HOME/build-tools/35.0.0/apksigner" verify --verbose app/build/outputs/apk/debug/app-debug.apk
sha256sum app/build/outputs/apk/debug/app-debug.apk
```

O bootstrap respeita `GRADLE_USER_HOME`, proxies e certificados do ambiente. Sem cache e com `--offline`, falha sem tentar rede. Para substituir o bootstrap pelo wrapper padrão, após um build validado execute `./gradlew wrapper --gradle-version 8.13 --distribution-type bin --gradle-distribution-sha256-sum 20f1b1176237254a6fc204d8434196fa11a4cfb387567519c61556e8710aed78`; revise e versione o JAR/scripts gerados. O checksum oficial do JAR 8.13 é `81a82aaea5abcc8ff68b3dfcb58b3c3c429378efd98e7433460610fecd7ae45f`, conforme [Gradle](https://gradle.org/release-checksums/). Um build só é validado quando o comando termina com sucesso e o APK é inspecionado.

## 4. Instalar

Ative depuração USB no aparelho, conecte-o e autorize a chave do computador:

```sh
adb devices
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

O APK debug é instalável para desenvolvimento, mas não substitui uma release assinada. Não publique uma chave privada de produção no repositório. Se outra assinatura já estiver instalada, a atualização será recusada; preservar ou remover dados deve ser uma decisão consciente do usuário.

## 5. Emulador e testes Android

Em máquina x86_64 com virtualização disponível:

```sh
sdkmanager 'emulator' 'system-images;android-35;google_apis;x86_64'
avdmanager create avd -n openframe_api35 -k 'system-images;android-35;google_apis;x86_64'
"$ANDROID_HOME/emulator/emulator" -avd openframe_api35
```

Depois do boot, em outro terminal:

```sh
./gradlew connectedDebugAndroidTest
```

A ausência de `/dev/kvm` reduz muito a viabilidade/performance do emulador. Use aparelho físico quando possível. Testes de codec em emulador não garantem o mesmo comportamento em encoders de fabricantes.

## Diagnóstico breve

| Falha | Verificação |
| --- | --- |
| `SDK location not found` | `ANDROID_HOME` ou `sdk.dir` em `local.properties` local |
| `javac` ausente | JDK completo, não apenas JRE |
| Proxy recusado | Rede/proxy configurado no sistema; não repetir downloads indefinidamente |
| Dependência não encontrada | Versão fixa, repositórios configurados e acesso Google/Maven |
| Memória insuficiente | Reduzir workers Gradle; não aumentar heap além da RAM disponível |
| Encoder indisponível | Testar aparelho com H.264 surface encoder; registrar erro/API/codec |

Para build offline, SDK, distribuição Gradle e todo o grafo de dependências precisam estar previamente disponíveis em cache; `--offline` não cria arquivos ausentes.
