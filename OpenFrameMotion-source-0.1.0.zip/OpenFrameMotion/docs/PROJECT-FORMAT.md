# Formato de projeto OpenFrame, schema 1

Fonte normativa: `core/model/.../Project.kt`, sua validação e `ProjectCodec`. O arquivo JSON é um documento local; não é XML Alight Motion nem um pacote portátil de mídias.

## Documento

| Campo | Semântica |
| --- | --- |
| `schemaVersion` | Inteiro, atualmente `1`; versões futuras exigem um leitor compatível |
| `id` | Identificador persistente seguro para armazenamento |
| `name` | Nome apresentado ao usuário |
| `width`, `height` | Resolução lógica, pixels inteiros |
| `fps` | Taxa de quadros escolhida para o projeto |
| `durationMs` | Duração em milissegundos |
| `backgroundColor` | Cor ARGB de 32 bits representada como número `Long` positivo |
| `createdAt`, `updatedAt` | Timestamps Unix em milissegundos |
| `layers` | Lista de camadas; índice maior aparece à frente |

## Camada

`id`, `name`, `type`, `startMs`, `durationMs`, `visible`, `transform`, `width`, `height`, `color`, `shape`, `text`, `fontSize`, `mediaRef`, `tracks`.

Tipos implementados no modelo: `SHAPE`, `TEXT`, `IMAGE`. Formas: `RECTANGLE`, `ELLIPSE`. Cada camada ocupa o intervalo fechado no início e aberto no fim. Tempo fora desse intervalo não a torna visível, mesmo quando uma trilha possui keyframes nesse instante.

`mediaRef` é um nome de arquivo no diretório privado de mídia, não uma URL ou caminho arbitrário. Copiar somente o JSON não transporta a mídia. Um pacote de compartilhamento exigirá manifesto, assets, verificação de integridade e proteção contra caminhos maliciosos.

## Transformação e keyframes

Posições `x`, `y` estão em pixels do projeto. `scaleX` e `scaleY` são fatores; `rotation` está em graus. `opacity` varia de 0 a 1. `anchorX` e `anchorY` são coordenadas relativas às dimensões da camada, normalmente entre 0 e 1. A posição identifica onde a âncora aparece no projeto.

Cada `AnimationTrack` contém uma propriedade e seus `keyframes`. As propriedades são `X`, `Y`, `SCALE_X`, `SCALE_Y`, `ROTATION`, `OPACITY`, `ANCHOR_X`, `ANCHOR_Y`. O `timeMs` de um keyframe é relativo ao início da camada. O easing pertence ao keyframe de saída de cada segmento.

Presets: `LINEAR`, `EASE_IN`, `EASE_OUT`, `EASE_IN_OUT`, `HOLD`, `CUBIC_BEZIER`. A curva armazena `x1`, `y1`, `x2`, `y2`; o avaliador resolve a componente X da Bézier antes de obter Y. Rotação interpola o valor numérico; não presume o caminho angular mais curto.

## Exemplo mínimo

```json
{
  "schemaVersion": 1,
  "id": "demo-project",
  "name": "Demonstração",
  "width": 1080,
  "height": 1920,
  "fps": 30,
  "durationMs": 5000,
  "backgroundColor": 4279243546,
  "createdAt": 0,
  "updatedAt": 0,
  "layers": []
}
```

## Compatibilidade e migrações

O schema 1 é a primeira versão; não existe migração de uma versão anterior de produção. A validação impõe dimensões, limites de contagem, duração e números finitos. O codec determina o tratamento de campos desconhecidos; um número de schema futuro nunca deve ser rebaixado por tentativa e erro.

Para um schema 2, implemente transformação explícita `v1 → v2`, fixtures representativas, preservação do arquivo original, testes de ida e volta e abertura sem perdas. Atualizar só o número de versão não é uma migração.

Não há compatibilidade declarada com XML de Alight Motion. Um importador futuro deve ocupar módulo próprio, operar apenas sobre documentação/amostras legalmente obtidas e emitir avisos para estruturas não suportadas. É necessário testar arquivos reais antes de afirmar compatibilidade.
