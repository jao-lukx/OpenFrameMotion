# Arquitetura

## Fluxo de dados

```mermaid
flowchart TD
    UI[Compose: projetos, timeline, propriedades] --> A[StudioActions / estado no app]
    A --> M[MotionProject imutável]
    A --> P[ProjectStore: JSON atômico]
    M --> E[AnimationEngine: tempo → Transform]
    M --> R[CompositionRenderer]
    E --> R
    R --> V[Bitmap do preview]
    R --> X[Frames da exportação]
    X --> G[EGL: textura para Surface]
    G --> C[MediaCodec H.264]
    C --> U[MediaMuxer MP4]
```

`app` é a composição de dependências: possui ciclo de vida, estado observável, I/O, seleção de mídia e operações do editor. `feature/editor` recebe estado e ações; não decide onde persistir. Os módulos JVM de modelo, animação e persistência podem ser testados sem aparelho Android.

## Modelo e tempo

`MotionProject` contém metadados e camadas em ordem de trás para frente. Cada camada tem ID próprio, intervalo `[startMs, startMs + durationMs)`, tipo visual, transformações e trilhas de animação. Keyframes usam tempo local à camada. O avaliador não lê o relógio do sistema: o mesmo projeto e o mesmo instante produzem as mesmas transformações.

Na reprodução, o aplicativo avança o tempo do projeto; na exportação, cada frame usa um índice e o FPS do projeto. O renderizador recebe o tempo explicitamente. Isso evita associar a velocidade da animação à velocidade da UI ou do encoder.

## Renderização inicial

O renderer inicial rasteriza com `android.graphics.Canvas` em Bitmap. A mesma implementação desenha fundo, formas, texto, imagens e transformações no preview e nos frames enviados ao encoder. A ordem da lista define composição alfa e sobreposição.

Um Bitmap de preview não é o documento: reduzir a resolução de preview não modifica coordenadas, duração ou imagem de origem. O renderizador deve preservar proporção e limitar o cache de imagens. Cada instância pertence a uma execução/thread; o preview e o exportador não compartilham instâncias mutáveis.

Na exportação, EGL/OpenGL ES envia os frames rasterizados para a input Surface do MediaCodec. Essa passagem usa GPU, mas a composição inicial continua sendo Canvas. Não existem Gaussian blur, glow, chroma key, máscaras ou motion blur nesta versão. Não se promete 60 FPS para 64 camadas em celulares intermediários.

## Persistência

O formato é JSON legível e versionado. `ProjectCodec` valida antes de aceitar ou escrever dados. `ProjectStore` usa escrita temporária e substituição atômica, com cópia de recuperação. Operações de disco são serializadas pelo app para impedir que snapshots antigos sobrescrevam edições recentes.

Um projeto com schema futuro não deve ser regravado silenciosamente. Arquivos corrompidos devem ser preservados e identificados, enquanto projetos íntegros continuam acessíveis. Migrações futuras exigem cópia preservada e teste contra arquivos de versões anteriores.

## Evolução para vídeo, áudio e GPU

1. Introduzir um frame source por tipo de mídia, com seek por timestamp e política de cache. Os decoders não pertencem à UI.
2. Separar áudio PCM, mixagem, resampling e sincronização; só então incluir uma trilha AAC no muxer.
3. Evoluir o renderer para uma interface de backend. Implementar backend OpenGL ES com textures/FBOs, blending premultiplicado, shaders e recuperação de contexto.
4. Manter o avaliador de animação e a semântica de tempo. Uma suíte de cenas de referência deve comparar Canvas e GPU antes de trocar o backend padrão.
5. Integrar Media3 onde suas APIs de playback/composição se ajustarem. Ele não substitui o modelo de documentos nem a matemática dos keyframes.

Grupos e máscaras exigirão uma árvore ou grafo de composição com validação de ciclos. Eles não devem ser adicionados como flags sem semântica de renderização/exportação correspondente.

## Limites de execução

Projeto inicial: até 64 camadas, 60 s, 64–4096 px, FPS 24/25/30/60 e 256 keyframes por trilha. A exportação inicial reduz resolução para um teto documentado no exportador; codecs podem impor restrições adicionais. Perfis em aparelhos reais ainda são necessários. Consulte [TEST-PLAN.md](TEST-PLAN.md) para medidas e critérios.
