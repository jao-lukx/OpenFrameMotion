# Relatório de implementação e validação — 2026-10-25

**Estado: código-fonte integrado; compilação Android e execução ainda não validadas. Não há APK produzido. Milestone 1 não está concluída.**

## Implementado em código

- Sete módulos reais: app, modelo, animação, persistência, renderização, editor e exportação.
- Home Compose/Material3, miniaturas da composição, criação/configuração de projeto, renomear, duplicar e excluir.
- Formas retangulares/elipses, texto e imagens JPEG/PNG/WebP via SAF; imagens copiadas para armazenamento privado, normalizadas para PNG com orientação EXIF e limite de 2048 px/32 MiB de entrada.
- Timeline com camadas, duração/início, visibilidade, ordem, cursor, zoom, reprodução e seleção por toque.
- Transformações, keyframes em oito propriedades, linear/ease/hold/Bézier e controle básico de curva por toque. Cursor usa timestamps racionais para evitar recuar um frame ao selecionar um timestamp já quantizado.
- Undo/redo limitado a 64 revisões, salvamento assíncrono, JSON v1 validado, escrita atômica/backup, avisos de recuperação e recusa de schemas futuros.
- Renderizador Canvas compartilhado por preview/miniaturas/exportação; preview fora da main thread, com fila conflada que termina o frame corrente e descarta pedidos intermediários. Miniaturas usam imagens reduzidas e cache de 2 MiB; preview usa até 24 MiB, export até 32 MiB de cache de imagens.
- Exportador separado MediaCodec/MediaMuxer/EGL para MP4/H.264, sem áudio, sem marca-d'água, preservando proporção até 720×1280/1280×720, progresso e cancelamento. O temporário é removido; se o provedor SAF recusar remover o destino parcial, o erro é comunicado.
- Licenças no app, documentação, guia Arch, CI e testes instrumentados preparados.

## Execuções e evidências

| Verificação | Resultado |
| --- | --- |
| Inspeção inicial/retomada dos arquivos | Executada; nenhum arquivo existente apagado |
| `./gradlew assembleDebug` | Tentada; código de saída 1 antes de iniciar o Gradle |
| Motivo | Conexão de rede negada ao baixar Gradle: `Operation not permitted`; curl também encontrou proxy inacessível |
| Log do build | [validation/assembleDebug.log](validation/assembleDebug.log) |
| Testes JUnit JVM | Escritos, não executados: compilador Kotlin/Gradle/dependências indisponíveis |
| Android Lint | Não executado: mesma ausência de toolchain |
| Testes Android de UI/render/MP4 | Escritos, não executados: SDK, ADB, emulador/aparelho ausentes |
| Instalação e assinatura do APK | Não executadas: nenhum APK gerado |
| CI GitHub Actions | Arquivos preparados, workflow não executado/publicado |
| Auditoria transitiva de licenças | Pendente da resolução dos artefatos |
| Integridade local, sintaxe shell/Python, XML/TOML e YAML dos workflows | Executadas com sucesso; sem compilação Kotlin |

As verificações offline de integridade do repositório ficam em `validation/repository-checks.log`: estrutura dos módulos, aliases Gradle, XML, links locais, assets de licença e sintaxe dos scripts Python. Isso **não é** compilação Kotlin, lint Android, teste de UI ou validação de codec. O relatório do script conta testes presentes sem alegar execução.

## Bloqueio preciso

[BUILD-ENVIRONMENT.md](BUILD-ENVIRONMENT.md) registra configuração observada e falhas de conexão. A política cloud aparece habilitada, mas o executor não obtém conexão utilizável. JDK 17, Gradle, SDK e caches não estão disponíveis. A pesquisa web funciona por uma ferramenta separada e não instala binários no workspace. Downloads não foram repetidos indefinidamente.

O launcher `gradlew` é um bootstrap em fonte Python com checksum Gradle oficial fixado. Ele não é o wrapper JAR padrão e exige Python 3.9+. Não houve substituição do SDK por mocks ou criação de arquivo APK fictício.

## Próxima validação reproduzível

Com JDK 17, Python, SDK 36 e Build Tools 35.0.0 disponíveis:

```sh
./gradlew :core:model:test :core:animation:test :core:persistence:test :feature:export:testDebugUnitTest
./gradlew lintDebug assembleDebug
./gradlew connectedDebugAndroidTest
```

Inspecionar `app/build/outputs/apk/debug/app-debug.apk`, executar `apksigner verify`, instalar e testar o fluxo de criação/edição/reabertura. O teste de exportação verifica trilha H.264, timestamps e comparação tolerante entre frames do MP4 decodificado e renderizador de referência. Nenhuma dessas propriedades do vídeo foi confirmada em dispositivo nesta sessão.

## Recursos incompletos

Vídeo/áudio como camadas, áudio exportado, máscaras, grupos, vetores editáveis, efeitos GPU, gráfico de velocidade, fontes personalizadas, pacote compartilhável de projetos/mídia, importação XML Alight Motion, exportações alternativas e profiling em aparelhos. Nenhum botão desses recursos foi exposto como ação implementada. A qualidade/performance do backend Canvas e a compatibilidade de codecs exigem medições reais. Também faltam publicação no GitHub, release assinada e auditoria das transitivas resolvidas.
