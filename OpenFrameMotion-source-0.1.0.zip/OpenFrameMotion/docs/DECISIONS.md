# Decisões técnicas

## ADR-001 — Entrega nativa incremental

**Decisão:** Kotlin, Compose e APIs Android, sem WebView como editor. A primeira base concentra formas, texto e imagens. **Motivo:** permitir um editor executável com documento real, preview e persistência antes de adicionar decodificação multicamadas. **Consequência:** vídeo/áudio como camadas permanecem pendentes, claramente identificados.

## ADR-002 — Stack fixa e conservadora

**Decisão:** AGP 8.13.2, Gradle 8.13, Kotlin 2.2.21 e Compose BOM 2025.10.01; minSdk 26 e compile/targetSdk 36. **Motivo:** conjunto estável com compatibilidade documentada, sem migração simultânea para Kotlin embutido de AGP 9. **Consequência:** não se apresenta a stack como a mais recente em 2026. Atualizações devem passar pelos mesmos testes antes de alterar versões.

## ADR-003 — Modelo JVM independente

**Decisão:** documentos, validação, animação e JSON sem Android. **Motivo:** matemática determinística e testes rápidos sem emulador. **Consequência:** tipos Android e detalhes de armazenamento do aparelho ficam nas bordas.

## ADR-004 — JSON atômico em vez de Room na primeira versão

**Decisão:** documentos pequenos com codec versionado e escrita atômica. **Motivo:** evitar banco e geração KSP enquanto o documento é a unidade natural de gravação. **Consequência:** listagem lê documentos; um índice em Room pode ser acrescentado quando medições justificarem, mantendo o formato de documento independente.

## ADR-005 — Canvas como primeiro backend comum

**Decisão:** usar o mesmo código de composição em preview e export; transferir Bitmap para Surface de encoder via EGL. **Motivo:** reduzir divergência visual e entregar uma base de renderização verificável. **Consequência:** composição é majoritariamente raster/CPU e não representa o objetivo final de pipeline GPU; exportação tem teto de resolução e exige profiling.

## ADR-006 — Mídia local por seletor Android

**Decisão:** importar imagens via seletor de documentos e copiar para armazenamento privado. **Motivo:** não depender de permissões amplas nem de referências externas que podem desaparecer. **Consequência:** projeto JSON sozinho não é pacote compartilhável; coleta de mídias órfãs e empacotamento ficam para evolução.

## ADR-007 — Media3 e FFmpeg não são dependências iniciais

**Decisão:** não carregar bibliotecas de mídia sem uma funcionalidade atual que as use. A base de export usa os codecs do sistema. **Motivo:** controlar escopo, tamanho e licenciamento. **Consequência:** ao implementar áudio/vídeo, avaliar Media3 com testes de sincronização, sem confundi-lo com o motor completo de motion graphics.

## ADR-008 — GPL-3.0-or-later para código original

**Decisão:** licença copyleft GPL versão 3 ou posterior. **Motivo:** manter modificações distribuídas abertas e acomodar dependências Apache-2.0. **Consequência:** a distribuição do APK deve acompanhar código correspondente e avisos. A revisão das dependências diretas não substitui o inventário do grafo transitivo resolvido.
