# Roadmap verificável

Uma milestone só é concluída após código integrado, testes relevantes, build real, verificação do APK e registro dos limites. Consulte [TEST-REPORT.md](TEST-REPORT.md) para resultados efetivos; esta lista descreve critérios e pendências.

| Milestone | Critério de aceite | Situação da base 0.1 |
| --- | --- | --- |
| 1 — APK inicial | Criar/salvar/reabrir projeto, camada visual, preview, timeline, APK instalado | Código em integração; evidência no relatório |
| 2 — Edição básica | Imagem e vídeo, manipulação, duração, playback, undo/redo | Imagens e operações básicas na base; vídeo pendente |
| 3 — Animação | Keyframes reais, propriedades e easing editáveis | Motor e controles básicos na base; editor gráfico completo pendente |
| 4 — Exportação | MP4 correspondente ao preview, progresso/cancelamento, teste do arquivo | Pipeline visual H.264 inicial; áudio e validação entre aparelhos pendentes |
| 5 — Motion graphics | Curvas por gesto, máscaras, grupos, efeitos GPU e profiling | Editor Bézier básico implementado em fonte; demais recursos pendentes |
| 6 — Ecossistema | Docs, CI, repo público, releases, licenças verificadas | Docs e workflows preparados; publicação/release pendentes |

## Próximos incrementos

1. Executar o fluxo completo em aparelho API 26 e atual: criação, edição, encerramento do processo, reabertura e export.
2. Resolver regressões de codecs e persistência antes de aumentar limites.
3. Adicionar vídeo com timestamp determinístico, rotação e proporção; testar VFR e arquivos inválidos.
4. Adicionar áudio com mixagem e sincronização, trim e AAC; validar o atraso inicial/final no MP4.
5. Validar e expandir o editor Bézier básico por toque com overshoot e visualização de velocidade.
6. Substituir composição raster por backend GPU mantendo comparação de frames.
7. Implementar máscaras/grupos e efeitos, cada um com teste visual; nenhum controle ornamental.
8. Adicionar import/export de pacote OpenFrame com mídias e checagem de integridade.
9. Investigar XML de terceiros a partir de documentação pública e arquivos autorizados; só divulgar suporte aos elementos realmente testados.
10. Publicar repositório e releases assinadas depois de configurar proprietário, canal de segurança e inventário transitivo.

## Recursos ainda ausentes

Vídeo/áudio na timeline, fontes personalizadas, vetores editáveis, máscaras, grupos, efeitos GPU, motion blur, chroma key, exportação HEVC/GIF/PNG sequence, exportação com áudio, editor avançado de curvas, importação XML de terceiros, colaboração e sincronização cloud.

Não há compromisso de prazo nem promessa de paridade universal. A prioridade permanece um documento editável confiável e uma saída visual que corresponda a ele.
