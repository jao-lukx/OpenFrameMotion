# Contratos de implementação — v0.1

Pacote raiz `org.openframe`. Modelo imutável em `core/model/.../Project.kt` (não alterar nomes sem coordenação).

- `core:animation`: `object AnimationEngine { fun evaluate(layer: Layer, projectTimeMs: Long): Transform; fun evaluateTrack(track: AnimationTrack, localTimeMs: Long, defaultValue: Float): Float; fun interpolate(fraction: Float, easing: Easing, curve: BezierCurve = BezierCurve()): Float }`. Keyframes relativos ao início da camada; easing do keyframe de saída.
- `core:persistence`: `class ProjectStore(directory: File)` com `fun list(): List<MotionProject>`, `fun load(id: String): MotionProject`, `fun save(project: MotionProject)`, `fun delete(id: String)`, `fun duplicate(id: String): MotionProject`. Erros explícitos; todas chamadas em IO pelo app. `object ProjectCodec { fun encode(project): String; fun decode(json: String): MotionProject }`. Validação de limites no modelo via `fun MotionProject.validated(): MotionProject`.
- `core:rendering`: `class CompositionRenderer(mediaDirectory: File) : java.io.Closeable { fun render(canvas: android.graphics.Canvas, project: MotionProject, timeMs: Long, width: Int, height: Int); fun renderBitmap(project: MotionProject, timeMs: Long, width: Int, height: Int): android.graphics.Bitmap; override fun close() }`. Fundo opaco, fit da composição sem distorção; texto, formas, imagens; cache limitado. Mesmo avaliador e desenho no preview/export.
- `feature:export`: `class VideoExporter(mediaDirectory: File) { suspend fun export(project: MotionProject, output: File, onProgress: (Float) -> Unit) }`. MP4/H264 sem áudio, limite de saída inicial até 720p; cancelamento coroutine e remoção de arquivo parcial. Renderer compartilhado; nunca copiar mídia como exportação.
- `feature:editor`: `@Composable fun OpenFrameApp(state: StudioState, actions: StudioActions, mediaDirectory: File)`; contratos em `UiContracts.kt`. UI sem operações de disco. Preview pode usar `produceState` em Dispatchers.Default com renderer dedicado; não reutilizar renderer entre threads. Navegação controlada por `state.project`.
- `app`: Activity, ViewModel/StateFlow, persistência assíncrona serializada, SAF image copy, export SaveDocument, ciclo de vida, undo/redo e controles.

Limites M1: 64 camadas, 60 s, dimensões 64–4096, FPS 24/25/30/60, 256 keyframes por trilha. Sem vídeo/áudio na timeline nem XML de terceiros nesta versão. Não expor controles sem implementação.

Ownership: A = modelo validação/persistência; B = feature/editor UI (exceto contratos); C = core/animation; D = core/rendering e feature/export; E = docs/CI/licenças; principal = build/app/integração. Build scripts sob responsabilidade principal. Fontes de módulos JVM não dependem de Android.
