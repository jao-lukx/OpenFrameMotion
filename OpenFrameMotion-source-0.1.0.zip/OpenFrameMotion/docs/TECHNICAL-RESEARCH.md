# Pesquisa técnica — 2026-10-25

Consulta objetiva às fontes oficiais. Versões selecionadas abaixo são fixas e conservadoras, não apresentadas como as mais recentes. Disponibilidade dos artefatos e compatibilidade concreta precisam ser confirmadas pelo Gradle; resultados de execução estão em [TEST-REPORT.md](TEST-REPORT.md).

## Compatibilidade e seleção

| Componente | Seleção | Evidência e decisão |
| --- | --- | --- |
| Android Gradle Plugin | 8.13.2 | A [linha 8.13](https://developer.android.com/build/releases/agp-8-13-0-release-notes) suporta API 36.1 e requer Gradle 8.13/JDK 17; atende compileSdk 36 |
| Gradle | 8.13 | Pareamento explícito nas notas do AGP; wrapper fixa distribuição |
| Kotlin + plugins Compose/serialization | 2.2.21 | [Release estável de correção](https://kotlinlang.org/docs/releases.html), da linha 2.2; plugins mantidos na mesma versão |
| Compose | BOM 2025.10.01 | Versões de runtime/UI/Material alinhadas por [BOM](https://developer.android.com/develop/ui/compose/bom); compiler controlado pelo plugin Kotlin, separado do BOM |
| Coroutines | 1.10.2 | [Release oficial](https://github.com/Kotlin/kotlinx.coroutines/releases/tag/1.10.2) para tarefas canceláveis/Flow; sem schedulers externos |
| Serialization JSON | 1.9.0 | [Release oficial](https://github.com/Kotlin/kotlinx.serialization/releases/tag/v1.9.0) usa Kotlin 2.2; modelo serializável sem reflexão Android |
| Android SDK | compile/target 36, min 26 | Cobertura Android 8+; SDK não é redistribuído no projeto |
| JUnit | 4.13.2 | Testes JVM e integração com ferramentas Android; somente classpath de testes |

A documentação atual também apresenta AGP 9.4, Kotlin 2.4.21 e Compose 1.12.1, mas a migração de AGP 9 envolve [Kotlin embutido](https://developer.android.com/build/migrate-to-built-in-kotlin). A entrega inicial evita mudar o modelo de plugin junto com a implementação do editor. Uma atualização futura deve conferir requisitos de SDK, notas de migração e build real, sem versões dinâmicas `+`.

## APIs de mídia

A [página de releases Media3](https://developer.android.com/jetpack/androidx/releases/media3) apresenta a linha estável 1.11.1 na consulta. Media3 é uma opção para fontes de vídeo/áudio, reprodução e edição. Sua API de [Composition](https://developer.android.com/media/media3/transformer/composition) organiza sequências e efeitos, mas tem restrições próprias; não define o documento de motion graphics nem substitui o avaliador de keyframes do OpenFrame.

Nesta base, não há dependência Media3 sem uso. A composição visual inicial gera frames pelo próprio renderizador; MediaCodec e MediaMuxer produzem H.264/MP4. O backend de composição é Canvas e a passagem ao encoder usa EGL. A implementação precisa confirmar suporte de encoder, finalização do muxer, timestamps e cancelamento em dispositivo. MP4 sem áudio não equivale a edição de vídeo/áudio multicamadas.

Fontes de referência: [MediaCodec](https://developer.android.com/reference/android/media/MediaCodec), [MediaMuxer](https://developer.android.com/reference/android/media/MediaMuxer), [EGL14](https://developer.android.com/reference/android/opengl/EGL14) e [seletor de documentos](https://developer.android.com/training/data-storage/shared/documents-files).

## Persistência

Room é adequado para índices e consultas, mas não é necessário para o primeiro conjunto de documentos pequenos. JSON versionado com gravação atômica mantém o formato transparente, reduz plugins e permite testes JVM. Futuro índice em Room pode apontar para os mesmos documentos sem vincular o formato ao schema SQL.

## Licenças e interoperabilidade

Código original sob GPL-3.0-or-later; runtime Kotlin/AndroidX/kotlinx majoritariamente Apache-2.0. A [FSF descreve compatibilidade Apache-2.0 com GPLv3](https://www.gnu.org/licenses/license-list.en.html#apache2). Isso não dispensa preservar avisos nem auditar transitivas: veja [LICENSES.md](LICENSES.md).

Não foi identificada nesta entrega uma especificação pública suficiente e uma suíte de amostras autorizadas para declarar compatibilidade XML de Alight Motion. Não há importador implementado. Uma investigação posterior deve separar documentação pública, autorização dos arquivos de teste e elementos efetivamente suportados; engenharia reversa de código proprietário não faz parte do projeto.
