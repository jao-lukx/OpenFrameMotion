# Plano de testes e desempenho

Este documento define procedimentos e critérios. Resultados executados pertencem a [TEST-REPORT.md](TEST-REPORT.md).

## Testes JVM

```sh
./gradlew :core:model:test :core:animation:test :core:persistence:test
```

- Validação: dimensões, duração, IDs, números não finitos, bounds e contagem de camadas/keyframes.
- Animação: tempos antes/depois dos pontos, início local da camada, interpolação linear/hold/ease/Bézier e opacidade.
- Codec: ida e volta de tipos/transformações/keyframes, versão futura, campos desconhecidos e JSON inválido.
- Store: duplicação sem colisão de IDs, gravação/abertura, backup válido após truncamento, arquivo corrompido isolado e proteção de caminhos.

## Testes Android

```sh
./gradlew connectedDebugAndroidTest
```

Renderização deve verificar pixels de cenas sintéticas: fundo, transparência, z-order, texto, âncora/transformação, tempo de camada e imagem inválida. Exportação deve produzir MP4, identificar a trilha H.264, verificar dimensões/duração/timestamps, decodificar frames e comparar as posições/cores com os frames de referência. H.264 é lossy: a comparação usa tolerância, não igualdade binária.

Para consistência visual, uma cena com fundo escuro, retângulo colorido em movimento e texto permite detectar vídeo vazio, orientação invertida, composição ignorada e timestamps incorretos. Amostre início, meio e fim. Se a validação detectar um codec indisponível, registre como não executado para aquele aparelho; não como sucesso de exportação.

## Roteiro manual mínimo

1. Abrir o aplicativo limpo; criar projetos retrato, paisagem e quadrado.
2. Adicionar forma, texto e imagem; mover, escalar, girar, alterar opacidade e ordem; verificar preview após cada ação.
3. Editar início/duração; scrub antes, dentro e depois do intervalo. Alterar zoom e rolar a timeline.
4. Criar dois keyframes, reproduzir e conferir easing. Excluir keyframe e verificar mudança real.
5. Desfazer/refazer, voltar à home, reabrir, renomear, duplicar e excluir o projeto duplicado.
6. Encerrar o processo durante uso e reabrir; conferir a última gravação confirmada. Simular um JSON truncado em build de teste e conferir recuperação/diagnóstico.
7. Importar arquivo inválido, imagem grande e mídia indisponível; confirmar erro recuperável e memória limitada.
8. Exportar 5 s; reproduzir MP4 em outro player; conferir camadas, animação, fundo e orientação.
9. Cancelar exportação em andamento; verificar remoção do temporário e edição ainda utilizável.
10. Repetir em API 26 e versão atual, retrato/paisagem, fonte ampliada, tela pequena e TalkBack.

## Benchmarks propostos

Não são medições concluídas. Registrar modelo do aparelho, API, RAM, temperatura, resolução e codec antes de comparar execuções.

| Cenário | Medida | Meta inicial a verificar |
| --- | --- | --- |
| 10 formas animadas, 5 s, preview reduzido | p95 do tempo de frame | até 33,3 ms para alvo 30 FPS |
| 5 imagens + texto, scrub repetido | p95 toque → preview atualizado | até 100 ms |
| 10 camadas, abrir/salvar projeto | p95 até confirmação | até 300 ms em armazenamento local |
| Export 5 s, 720p equivalente, 30 FPS | tempo total, FPS encoding, pico RSS | registrar sem prometer tempo real |
| 64 camadas/60 s | memória e resposta a cancelamento | sem ANR; erro explícito se recurso insuficiente |

Use Android Studio Profiler e Perfetto para CPU, memória e frames. Para GPU/codec, registre o nome do encoder e os tempos de produção/consumo. Rode cinco vezes após uma execução de aquecimento e reporte mediana/p95, falhas e outliers; não esconda thermal throttling.

## Gate de release

Uma release requer testes JVM, lint, build, assinatura verificada, checksum, instalação, roteiro de persistência e amostra exportada inspecionada. Incluir resultados do aparelho e lista do que não foi testado. O workflow de CI por si só não prova que uma release ou upload ocorreu.
