// SPDX-License-Identifier: GPL-3.0-or-later
package org.openframe.motion

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import java.io.File
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import org.openframe.model.newId

data class ImportedImage(val basename: String, val width: Int, val height: Int)

/** Copies SAF input into app-owned storage. 32 MiB input; 2048px decoded edge. No broad permissions. */
class ImageImporter(private val context: Context, private val mediaDirectory: File) {
    suspend fun importImage(uri: Uri): ImportedImage {
        check(mediaDirectory.isDirectory || mediaDirectory.mkdirs()) { "Armazenamento indisponível" }
        val source = File.createTempFile("import-", ".tmp", context.cacheDir)
        val target = File(mediaDirectory, "${newId()}.png")
        var bitmap: Bitmap? = null
        var oriented: Bitmap? = null
        var completed = false
        try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                source.outputStream().use { output ->
                    val buffer = ByteArray(64 * 1024)
                    var total = 0L
                    while (true) {
                        currentCoroutineContext().ensureActive()
                        val count = input.read(buffer)
                        if (count < 0) break
                        total += count
                        require(total <= 32L * 1024 * 1024) { "Imagem excede 32 MiB" }
                        output.write(buffer, 0, count)
                    }
                }
            } ?: error("Não foi possível ler o arquivo")
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(source.path, bounds)
            require(bounds.outWidth in 1..32768 && bounds.outHeight in 1..32768) { "Imagem inválida ou dimensões excessivas" }
            require(bounds.outMimeType in listOf("image/jpeg", "image/png", "image/webp")) { "Use JPEG, PNG ou WebP" }
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 2048) sample *= 2
            bitmap = BitmapFactory.decodeFile(source.path, BitmapFactory.Options().apply { inSampleSize = sample })
                ?: error("Imagem inválida")
            val orientation = ExifInterface(source).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            val matrix = Matrix().apply {
                when (orientation) {
                    ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> setScale(-1f, 1f)
                    ExifInterface.ORIENTATION_ROTATE_180 -> setRotate(180f)
                    ExifInterface.ORIENTATION_FLIP_VERTICAL -> setScale(1f, -1f)
                    ExifInterface.ORIENTATION_TRANSPOSE -> { setRotate(90f); postScale(-1f, 1f) }
                    ExifInterface.ORIENTATION_ROTATE_90 -> setRotate(90f)
                    ExifInterface.ORIENTATION_TRANSVERSE -> { setRotate(-90f); postScale(-1f, 1f) }
                    ExifInterface.ORIENTATION_ROTATE_270 -> setRotate(270f)
                }
            }
            oriented = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
            currentCoroutineContext().ensureActive()
            target.outputStream().use { output -> check(oriented.compress(Bitmap.CompressFormat.PNG, 100, output)) { "Falha ao salvar imagem" } }
            completed = true
            return ImportedImage(target.name, oriented.width, oriented.height)
        } finally {
            if (oriented !== bitmap) oriented?.recycle()
            bitmap?.recycle()
            source.delete()
            if (!completed) target.delete()
        }
    }
}
