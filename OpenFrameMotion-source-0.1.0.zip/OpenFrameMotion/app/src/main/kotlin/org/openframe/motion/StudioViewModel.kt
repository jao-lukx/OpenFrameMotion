// SPDX-License-Identifier: GPL-3.0-or-later
package org.openframe.motion

import android.app.Application
import android.net.Uri
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import java.io.File
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.*
import org.openframe.animation.AnimationEngine
import org.openframe.animation.FrameClock
import org.openframe.editor.StudioActions
import org.openframe.editor.StudioState
import org.openframe.export.VideoExporter
import org.openframe.model.*
import org.openframe.persistence.ProjectStore

sealed interface StudioEvent {
    data object PickImage : StudioEvent
    data class SaveVideo(val filename: String) : StudioEvent
}

/** All document mutations happen on Main. A single writer preserves save/delete ordering. */
class StudioViewModel(application: Application) : AndroidViewModel(application), StudioActions {
    val mediaDirectory = File(application.filesDir, "media")
    private val store by lazy { ProjectStore(File(application.filesDir, "projects")) }
    private val _state = MutableStateFlow(StudioState(busy = true))
    val state: StateFlow<StudioState> = _state.asStateFlow()
    private val eventChannel = Channel<StudioEvent>(Channel.BUFFERED)
    val events = eventChannel.receiveAsFlow()
    private sealed interface Write {
        data class Save(val project: MotionProject) : Write
        data class Delete(val project: MotionProject) : Write
    }
    private val writes = Channel<Write>(Channel.UNLIMITED)
    private val undoStack = ArrayDeque<MotionProject>()
    private val redoStack = ArrayDeque<MotionProject>()
    private var playbackJob: Job? = null
    private var exportJob: Job? = null
    private var pendingExport: MotionProject? = null

    init {
        viewModelScope.launch {
            runCatching { withContext(Dispatchers.IO) { store.list() to store.diagnostics } }
                .onSuccess { (projects, diagnostics) -> _state.update { it.copy(projects = projects, busy = false,
                    message = diagnostics.takeIf { entries -> entries.isNotEmpty() }?.joinToString("\n") { entry -> entry.message }) } }
                .onFailure { error -> _state.update { it.copy(busy = false, message = "Falha ao abrir projetos: ${error.message}") } }
        }
        viewModelScope.launch {
            for (write in writes) {
                try {
                    withContext(Dispatchers.IO) {
                        when (write) {
                            is Write.Save -> store.save(write.project)
                            is Write.Delete -> store.delete(write.project.id)
                        }
                    }
                    if (write is Write.Save && _state.value.project == write.project) {
                        _state.update { it.copy(saveStatus = "Salvo") }
                    }
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (error: Exception) {
                    if (write is Write.Delete) {
                        _state.update { current -> current.copy(projects = (current.projects.filterNot { it.id == write.project.id } + write.project).sortedByDescending { it.updatedAt }) }
                    }
                    _state.update { it.copy(saveStatus = "Falha ao salvar", message = "Armazenamento: ${error.message}") }
                }
            }
        }
    }

    private fun announce(message: String) { _state.update { it.copy(message = message) } }
    private fun queueSave(project: MotionProject) {
        writes.trySend(Write.Save(project))
        _state.update { if (it.project?.id == project.id) it.copy(saveStatus = "Salvando…") else it }
    }
    private fun publishProject(project: MotionProject) {
        _state.update { current -> current.copy(
            project = project,
            projects = (current.projects.filterNot { it.id == project.id } + project).sortedByDescending { it.updatedAt },
            canUndo = undoStack.isNotEmpty(), canRedo = redoStack.isNotEmpty(),
        ) }
        queueSave(project)
    }
    private fun edit(change: (MotionProject) -> MotionProject) {
        if (_state.value.busy) return
        val before = _state.value.project ?: return
        val after = try { change(before).validated() } catch (error: IllegalArgumentException) {
            announce(error.message ?: "Valor inválido")
            return
        }
        if (before == after) return
        undoStack.addLast(before)
        while (undoStack.size > 64) undoStack.removeFirst()
        redoStack.clear()
        publishProject(after.copy(updatedAt = System.currentTimeMillis()))
    }
    private fun selectedEdit(change: (Layer) -> Layer) {
        val id = _state.value.selectedLayerId ?: return
        edit { project -> project.copy(layers = project.layers.map { if (it.id == id) change(it) else it }) }
    }

    override fun createProject(name: String, width: Int, height: Int, fps: Int, durationMs: Long, backgroundColor: Long) {
        if (_state.value.busy) return
        val project = try {
            MotionProject(name = name.trim(), width = width, height = height, fps = fps,
                durationMs = durationMs, backgroundColor = backgroundColor).validated()
        } catch (error: IllegalArgumentException) { announce(error.message ?: "Projeto inválido"); return }
        pausePlayback()
        undoStack.clear(); redoStack.clear()
        _state.update { it.copy(selectedLayerId = null, playheadMs = 0) }
        publishProject(project)
    }

    override fun openProject(id: String) {
        if (_state.value.busy) return
        val project = _state.value.projects.firstOrNull { it.id == id } ?: return
        pausePlayback()
        undoStack.clear(); redoStack.clear()
        _state.update { it.copy(project = project, selectedLayerId = null, playheadMs = 0, canUndo = false, canRedo = false) }
    }
    override fun closeProject() {
        if (_state.value.busy) return
        pausePlayback(); save()
        undoStack.clear(); redoStack.clear()
        _state.update { it.copy(project = null, selectedLayerId = null, canUndo = false, canRedo = false) }
    }
    override fun renameProject(id: String, name: String) {
        if (_state.value.busy) return
        val original = _state.value.projects.firstOrNull { it.id == id } ?: return
        val project = try { original.copy(name = name.trim(), updatedAt = System.currentTimeMillis()).validated() }
            catch (error: IllegalArgumentException) { announce(error.message ?: "Nome inválido"); return }
        _state.update { it.copy(projects = it.projects.map { old -> if (old.id == id) project else old },
            project = if (it.project?.id == id) project else it.project) }
        queueSave(project)
    }
    override fun duplicateProject(id: String) {
        if (_state.value.busy) return
        val original = _state.value.projects.firstOrNull { it.id == id } ?: return
        val now = System.currentTimeMillis()
        val copy = original.copy(id = newId(), name = (original.name.take(110) + " (cópia)"), createdAt = now,
            updatedAt = now, layers = original.layers.map { it.copy(id = newId()) })
        _state.update { it.copy(projects = listOf(copy) + it.projects) }
        queueSave(copy)
    }
    override fun deleteProject(id: String) {
        if (_state.value.busy) return
        val project = _state.value.projects.firstOrNull { it.id == id } ?: return
        if (_state.value.project?.id == id) closeProject()
        _state.update { it.copy(projects = it.projects.filterNot { p -> p.id == id }) }
        writes.trySend(Write.Delete(project))
    }
    private fun addLayer(layer: Layer) {
        val before = _state.value.project ?: return
        if (before.layers.size >= 64) { announce("Limite inicial: 64 camadas por projeto"); return }
        edit { it.copy(layers = it.layers + layer) }
        if (_state.value.project?.layers?.any { it.id == layer.id } == true) selectLayer(layer.id)
    }
    override fun addShape(shape: ShapeKind) {
        val p = _state.value.project ?: return
        val size = minOf(p.width, p.height) * 0.4f
        addLayer(Layer(name = if (shape == ShapeKind.ELLIPSE) "Elipse" else "Retângulo", shape = shape,
            durationMs = p.durationMs, width = size, height = size,
            transform = Transform(x = p.width / 2f, y = p.height / 2f)))
    }
    override fun addText(text: String) {
        val p = _state.value.project ?: return
        addLayer(Layer(name = "Texto", type = LayerType.TEXT, text = text.take(2000), durationMs = p.durationMs,
            width = p.width * 0.8f, height = p.height * 0.3f, fontSize = minOf(p.width, p.height) * 0.09f,
            color = 0xFFF3F1FFL, transform = Transform(x = p.width / 2f, y = p.height / 2f)))
    }
    override fun importImage() {
        if (!_state.value.busy && _state.value.project != null) eventChannel.trySend(StudioEvent.PickImage)
    }
    fun onImageSelected(uri: Uri?) {
        if (uri == null || _state.value.busy) return
        val project = _state.value.project ?: return
        pausePlayback()
        _state.update { it.copy(busy = true) }
        viewModelScope.launch {
            try {
                val imported = withContext(Dispatchers.IO) { ImageImporter(getApplication(), mediaDirectory).importImage(uri) }
                _state.update { it.copy(busy = false) }
                if (_state.value.project?.id == project.id) {
                    val factor = minOf(project.width * 0.8f / imported.width, project.height * 0.8f / imported.height, 1f)
                    addLayer(Layer(name = "Imagem", type = LayerType.IMAGE, mediaRef = imported.basename,
                        durationMs = project.durationMs, width = imported.width * factor, height = imported.height * factor,
                        transform = Transform(x = project.width / 2f, y = project.height / 2f)))
                }
            } catch (cancelled: CancellationException) { throw cancelled }
            catch (error: Exception) { announce("Não foi possível importar: ${error.message}") }
            finally { _state.update { it.copy(busy = false) } }
        }
    }
    override fun selectLayer(id: String?) { _state.update { it.copy(selectedLayerId = id) } }
    override fun updateLayer(layer: Layer) {
        val p = _state.value.project ?: return
        val start = layer.startMs.coerceIn(0, p.durationMs - 1)
        val duration = layer.durationMs.coerceIn(1, p.durationMs - start)
        val normalized = layer.copy(startMs = start, durationMs = duration,
            tracks = layer.tracks.map { it.copy(keyframes = it.keyframes.filter { key -> key.timeMs <= duration }) }
                .filter { it.keyframes.isNotEmpty() })
        edit { it.copy(layers = it.layers.map { old -> if (old.id == layer.id) normalized else old }) }
    }
    override fun deleteSelectedLayer() {
        val id = _state.value.selectedLayerId ?: return
        edit { it.copy(layers = it.layers.filterNot { layer -> layer.id == id }) }
        selectLayer(null)
    }
    override fun duplicateSelectedLayer() {
        val layer = _state.value.selectedLayer ?: return
        addLayer(layer.copy(id = newId(), name = layer.name.take(110) + " (cópia)"))
    }
    override fun moveSelectedLayer(direction: Int) {
        val id = _state.value.selectedLayerId ?: return
        edit { project ->
            val layers = project.layers.toMutableList()
            val from = layers.indexOfFirst { it.id == id }
            if (from >= 0) {
                val to = (from + direction.coerceIn(-1, 1)).coerceIn(0, layers.lastIndex)
                layers.add(to, layers.removeAt(from))
            }
            project.copy(layers = layers)
        }
    }
    override fun setProperty(property: AnimatedProperty, value: Float) {
        if (!value.isFinite()) return
        val time = _state.value.playheadMs
        selectedEdit { layer ->
            val track = layer.tracks.firstOrNull { it.property == property }
            if (track == null || track.keyframes.isEmpty()) layer.copy(transform = layer.transform.withValue(property, value))
            else {
                val local = (time - layer.startMs).coerceIn(0, layer.durationMs - 1)
                val old = track.keyframes.firstOrNull { it.timeMs == local }
                val key = Keyframe(local, value, old?.easing ?: Easing.LINEAR, old?.curve ?: BezierCurve())
                val replacement = track.copy(keyframes = (track.keyframes.filterNot { it.timeMs == local } + key).sortedBy { it.timeMs })
                layer.copy(tracks = layer.tracks.map { if (it.property == property) replacement else it })
            }
        }
    }
    override fun toggleKeyframe(property: AnimatedProperty, easing: Easing) {
        val time = _state.value.playheadMs
        selectedEdit { layer ->
            val local = (time - layer.startMs).coerceIn(0, layer.durationMs - 1)
            val track = layer.tracks.firstOrNull { it.property == property } ?: AnimationTrack(property)
            val keys = if (track.keyframes.any { it.timeMs == local }) track.keyframes.filterNot { it.timeMs == local }
                else (track.keyframes + Keyframe(local, AnimationEngine.evaluate(layer, time).value(property), easing)).sortedBy { it.timeMs }
            layer.copy(tracks = layer.tracks.filterNot { it.property == property } +
                if (keys.isEmpty()) emptyList() else listOf(track.copy(keyframes = keys)))
        }
    }
    override fun setKeyframeEasing(property: AnimatedProperty, easing: Easing) {
        val time = _state.value.playheadMs
        selectedEdit { layer ->
            val local = (time - layer.startMs).coerceIn(0, layer.durationMs - 1)
            layer.copy(tracks = layer.tracks.map { track -> if (track.property != property) track else
                track.copy(keyframes = track.keyframes.map { if (it.timeMs == local) it.copy(easing = easing) else it }) })
        }
    }
    override fun seek(timeMs: Long) {
        val project = _state.value.project ?: return
        pausePlayback()
        _state.update { it.copy(playheadMs = FrameClock.snap(timeMs, project.durationMs, project.fps)) }
    }
    override fun togglePlayback() {
        if (_state.value.busy) return
        if (_state.value.playing) { pausePlayback(); return }
        val project = _state.value.project ?: return
        val start = if (_state.value.playheadMs >= project.durationMs - 1000 / project.fps) 0L else _state.value.playheadMs
        val clock = SystemClock.elapsedRealtime()
        _state.update { it.copy(playing = true, playheadMs = start) }
        playbackJob = viewModelScope.launch {
            while (isActive) {
                val now = start + SystemClock.elapsedRealtime() - clock
                if (now >= project.durationMs) { _state.update { it.copy(playing = false, playheadMs = 0) }; break }
                _state.update { it.copy(playheadMs = (now * project.fps / 1000) * 1000 / project.fps) }
                delay(16)
            }
        }
    }
    fun pausePlayback() { playbackJob?.cancel(); playbackJob = null; _state.update { it.copy(playing = false) } }
    override fun undo() {
        if (_state.value.busy || undoStack.isEmpty()) return
        pausePlayback()
        _state.value.project?.let(redoStack::addLast)
        publishProject(undoStack.removeLast().copy(updatedAt = System.currentTimeMillis()))
        ensureSelection()
    }
    override fun redo() {
        if (_state.value.busy || redoStack.isEmpty()) return
        pausePlayback()
        _state.value.project?.let(undoStack::addLast)
        publishProject(redoStack.removeLast().copy(updatedAt = System.currentTimeMillis()))
        ensureSelection()
    }
    private fun ensureSelection() {
        if (_state.value.selectedLayer == null) selectLayer(null)
    }
    override fun save() { _state.value.project?.let(::queueSave) }
    override fun exportVideo() {
        if (_state.value.busy) return
        val project = _state.value.project ?: return
        pausePlayback()
        pendingExport = project
        eventChannel.trySend(StudioEvent.SaveVideo("OpenFrame-${project.id.take(8)}.mp4"))
    }
    fun onExportDestinationSelected(uri: Uri?) {
        val snapshot = pendingExport.also { pendingExport = null } ?: return
        if (uri == null) return
        _state.update { it.copy(busy = true, exportProgress = 0f) }
        exportJob = viewModelScope.launch {
            val temporary = File(getApplication<Application>().cacheDir, "export-${newId()}.mp4")
            try {
                VideoExporter(mediaDirectory).export(snapshot, temporary) { progress ->
                    _state.update { it.copy(exportProgress = progress.coerceIn(0f, 1f) * 0.95f) }
                }
                withContext(Dispatchers.IO) {
                    val resolver = getApplication<Application>().contentResolver
                    resolver.openOutputStream(uri, "wt")?.use { output ->
                        temporary.inputStream().use { input ->
                            val buffer = ByteArray(64 * 1024)
                            while (true) {
                                ensureActive()
                                val count = input.read(buffer)
                                if (count < 0) break
                                output.write(buffer, 0, count)
                            }
                        }
                    } ?: error("Destino indisponível")
                }
                announce("Vídeo MP4 salvo. H.264, sem áudio, até 720p.")
            } catch (cancelled: CancellationException) {
                val removed = removePartialDocument(uri)
                announce(if (removed) "Exportação cancelada" else "Exportação cancelada; o provedor não permitiu remover o arquivo parcial no destino.")
                throw cancelled
            } catch (error: Exception) {
                val removed = removePartialDocument(uri)
                announce("Falha na exportação: ${error.message}" + if (removed) "" else " O provedor não permitiu remover o arquivo parcial.")
            } finally {
                temporary.delete()
                _state.update { it.copy(busy = false, exportProgress = null) }
            }
        }
    }
    private suspend fun removePartialDocument(uri: Uri): Boolean = withContext(NonCancellable + Dispatchers.IO) {
        runCatching { android.provider.DocumentsContract.deleteDocument(getApplication<Application>().contentResolver, uri) }.getOrDefault(false)
    }
    override fun cancelExport() { exportJob?.cancel() }
    override fun dismissMessage() { _state.update { it.copy(message = null) } }
}
