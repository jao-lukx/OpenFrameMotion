// SPDX-License-Identifier: GPL-3.0-or-later
package org.openframe.motion

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.launch
import org.openframe.editor.OpenFrameApp

class MainActivity : ComponentActivity() {
    private val model by lazy { ViewModelProvider(this)[StudioViewModel::class.java] }
    private val pickImage = registerForActivityResult(ActivityResultContracts.OpenDocument()) { model.onImageSelected(it) }
    private val saveVideo = registerForActivityResult(ActivityResultContracts.CreateDocument("video/mp4")) { model.onExportDestinationSelected(it) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                model.events.collect { event ->
                    when (event) {
                        StudioEvent.PickImage -> pickImage.launch(arrayOf("image/jpeg", "image/png", "image/webp"))
                        is StudioEvent.SaveVideo -> saveVideo.launch(event.filename)
                    }
                }
            }
        }
        setContent {
            OpenFrameApp(model.state.collectAsStateWithLifecycle().value, model, model.mediaDirectory)
        }
    }

    override fun onStop() {
        model.pausePlayback()
        model.save()
        super.onStop()
    }
}
