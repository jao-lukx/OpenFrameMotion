// SPDX-License-Identifier: GPL-3.0-or-later
package org.openframe.motion

import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import org.junit.Rule
import org.junit.Test
import org.junit.Assert.*
import org.openframe.persistence.ProjectStore
import java.io.File

class EditorFlowTest {
    @get:Rule val compose = createAndroidComposeRule<MainActivity>()

    @Test fun createEditSaveRecreateAndReopenProject() {
        val name = "Teste-${System.currentTimeMillis()}"
        compose.waitUntil(10_000) { compose.onAllNodes(hasTestTag("new_project") and isEnabled()).fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithTag("new_project").performClick()
        compose.onNodeWithTag("project_name").performTextReplacement(name)
        compose.onNodeWithTag("create_project").performClick()
        compose.onNodeWithTag("add_layer").performScrollTo().performClick()
        compose.onNodeWithTag("add_rectangle").performClick()
        compose.onNodeWithTag("undo").performScrollTo().performClick()
        compose.onNodeWithText("Adicione uma camada para começar.").assertExists()
        compose.onNodeWithTag("redo").performScrollTo().performClick()
        compose.onNodeWithTag("save_project").performScrollTo().performClick()
        val projectDir = File(compose.activity.filesDir, "projects")
        compose.waitUntil(10_000) {
            runCatching { ProjectStore(projectDir).list().any { it.name == name && it.layers.size == 1 } }.getOrDefault(false)
        }
        val project = ProjectStore(projectDir).list().single { it.name == name }
        assertEquals(1, project.layers.size)
        compose.onNodeWithTag("back_projects").performClick()
        compose.activityRule.scenario.recreate()
        compose.onNodeWithText(name).performScrollTo().performClick()
        compose.onNodeWithTag("back_projects").assertExists()
        assertEquals(project.layers, ProjectStore(projectDir).load(project.id).layers)
    }
}
