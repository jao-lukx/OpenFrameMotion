// SPDX-License-Identifier: GPL-3.0-or-later
package org.openframe.persistence

import kotlinx.serialization.SerializationException
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.intOrNull
import org.openframe.model.CURRENT_SCHEMA_VERSION
import org.openframe.model.MotionProject
import org.openframe.model.ProjectLimits
import org.openframe.model.validated

class UnsupportedProjectVersionException(val version: Int?) : IllegalArgumentException(
    "Versão de projeto não suportada: ${version ?: "ausente"}. O arquivo foi preservado.",
)

/** Version routing lives here; a future migration must be explicit and covered by fixtures. */
object ProjectCodec {
    private val json = Json {
        encodeDefaults = true
        ignoreUnknownKeys = true
        prettyPrint = true
        isLenient = false
        allowSpecialFloatingPointValues = false
    }

    fun encode(project: MotionProject): String {
        val encoded = json.encodeToString(project.validated())
        require(encoded.toByteArray(Charsets.UTF_8).size <= ProjectLimits.MAX_SERIALIZED_BYTES) {
            "Projeto excede o limite de 16 MiB"
        }
        return encoded
    }

    fun decode(source: String): MotionProject {
        require(source.length <= ProjectLimits.MAX_SERIALIZED_BYTES &&
            source.toByteArray(Charsets.UTF_8).size <= ProjectLimits.MAX_SERIALIZED_BYTES) {
            "Projeto excede o limite de 16 MiB"
        }
        val document = json.parseToJsonElement(source) as? JsonObject
            ?: throw SerializationException("O projeto deve ser um objeto JSON")
        val versionValue = document["schemaVersion"] as? JsonPrimitive
        val version = versionValue?.takeUnless { it.isString }?.intOrNull
        if (version != CURRENT_SCHEMA_VERSION) throw UnsupportedProjectVersionException(version)
        // Defaults must never invent an ID or timestamps while opening an incomplete file.
        val required = setOf("id", "name", "width", "height", "fps", "durationMs", "backgroundColor", "createdAt", "updatedAt", "layers")
        if (!document.keys.containsAll(required)) throw SerializationException("Metadados obrigatórios ausentes no projeto")
        val layers = document["layers"] as? JsonArray ?: throw SerializationException("Lista de camadas inválida")
        val requiredLayer = setOf("id", "name", "type", "startMs", "durationMs", "width", "height", "transform")
        layers.forEach { element ->
            val layer = element as? JsonObject ?: throw SerializationException("Camada inválida")
            if (!layer.keys.containsAll(requiredLayer)) throw SerializationException("Metadados obrigatórios ausentes na camada")
        }
        return json.decodeFromJsonElement(MotionProject.serializer(), document).validated()
    }
}
