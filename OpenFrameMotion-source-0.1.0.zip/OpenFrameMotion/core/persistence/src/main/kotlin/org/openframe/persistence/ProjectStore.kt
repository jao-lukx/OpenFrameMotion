// SPDX-License-Identifier: GPL-3.0-or-later
package org.openframe.persistence

import java.io.File
import java.io.FileNotFoundException
import java.io.FileOutputStream
import java.io.IOException
import java.nio.file.AtomicMoveNotSupportedException
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import org.openframe.model.MotionProject
import org.openframe.model.ProjectLimits
import org.openframe.model.isValidProjectId
import org.openframe.model.newId

enum class ProjectDiagnosticKind { RECOVERED_FROM_BACKUP, UNREADABLE_PROJECT, UNSUPPORTED_VERSION }

data class ProjectDiagnostic(val projectId: String, val kind: ProjectDiagnosticKind, val message: String)

/**
 * App-private JSON store. All public operations serialize on this instance.
 * Call from Dispatchers.IO. Keep one instance per directory in the application.
 *
 * Writes fsync the temporary file and replace by rename. A separately committed backup
 * retains the previous valid revision. Directory fsync is platform-dependent, so this
 * provides recovery from interrupted writes, not an absolute power-loss guarantee.
 */
class ProjectStore(directory: File) {
    private val root: File
    private val issues = mutableListOf<ProjectDiagnostic>()

    val diagnostics: List<ProjectDiagnostic>
        @Synchronized get() = issues.toList()

    init {
        if (!directory.exists() && !directory.mkdirs()) throw IOException("Não foi possível criar a pasta de projetos")
        require(directory.isDirectory) { "O caminho de projetos não é uma pasta" }
        root = directory.canonicalFile
    }

    @Synchronized
    fun list(): List<MotionProject> {
        issues.clear()
        val files = root.listFiles() ?: throw IOException("Não foi possível listar os projetos")
        val ids = files.mapNotNull { file ->
            when {
                file.name.endsWith(SUFFIX + BACKUP_SUFFIX) -> file.name.removeSuffix(SUFFIX + BACKUP_SUFFIX)
                file.name.endsWith(SUFFIX) -> file.name.removeSuffix(SUFFIX)
                else -> null
            }?.takeIf(::isValidProjectId)
        }.toSet()
        return ids.mapNotNull { id ->
            try {
                load(id)
            } catch (failure: UnsupportedProjectVersionException) {
                report(id, ProjectDiagnosticKind.UNSUPPORTED_VERSION, failure.message ?: "Versão não suportada")
                null
            } catch (failure: Exception) {
                report(id, ProjectDiagnosticKind.UNREADABLE_PROJECT, failure.message ?: "Projeto ilegível")
                null
            }
        }.sortedWith(compareByDescending<MotionProject> { it.updatedAt }.thenBy { it.id })
    }

    @Synchronized
    fun load(id: String): MotionProject {
        val file = projectFile(id)
        val backup = projectFile(id, backup = true)
        var primaryFailure: Exception? = null
        if (file.exists()) {
            try {
                return readProject(file, id).first
            } catch (failure: UnsupportedProjectVersionException) {
                // Never roll back a project produced by a newer app version.
                throw failure
            } catch (failure: Exception) {
                primaryFailure = failure
            }
        }
        if (backup.exists()) {
            try {
                val (project, source) = readProject(backup, id)
                writeAtomically(file, source)
                report(id, ProjectDiagnosticKind.RECOVERED_FROM_BACKUP, "Projeto recuperado da revisão anterior; a última alteração pode ter sido perdida")
                return project
            } catch (failure: UnsupportedProjectVersionException) {
                throw failure
            } catch (failure: Exception) {
                primaryFailure?.let(failure::addSuppressed)
                throw IOException("Projeto e cópia de recuperação ilegíveis: $id", failure)
            }
        }
        primaryFailure?.let { throw IOException("Projeto ilegível, sem cópia de recuperação: $id", it) }
        throw FileNotFoundException("Projeto não encontrado: $id")
    }

    @Synchronized
    fun save(project: MotionProject) {
        val source = ProjectCodec.encode(project)
        val file = projectFile(project.id)
        val backup = projectFile(project.id, backup = true)
        if (file.exists()) {
            val previous = try {
                readProject(file, project.id).second
            } catch (failure: UnsupportedProjectVersionException) {
                throw failure
            } catch (_: Exception) {
                // A damaged primary must not replace a valid backup.
                null
            }
            if (previous != null) writeAtomically(backup, previous)
        }
        writeAtomically(file, source)
    }

    @Synchronized
    fun delete(id: String) {
        val file = projectFile(id)
        val backup = projectFile(id, backup = true)
        // Delete recovery first: a failure then leaves the current project discoverable.
        Files.deleteIfExists(backup.toPath())
        Files.deleteIfExists(file.toPath())
        issues.removeAll { it.projectId == id }
    }

    @Synchronized
    fun duplicate(id: String): MotionProject {
        val original = load(id)
        val now = System.currentTimeMillis()
        val copy = original.copy(
            id = newId(),
            name = original.name.take(112) + " (cópia)",
            createdAt = now,
            updatedAt = now,
            layers = original.layers.map { it.copy(id = newId()) },
        )
        save(copy)
        return copy
    }

    private fun projectFile(id: String, backup: Boolean = false): File {
        require(isValidProjectId(id)) { "Identificador de projeto inválido" }
        val candidate = File(root, id + SUFFIX + if (backup) BACKUP_SUFFIX else "")
        require(!Files.isSymbolicLink(candidate.toPath()) && candidate.canonicalFile.parentFile == root) {
            "Caminho de projeto inválido"
        }
        return candidate
    }

    private fun readProject(file: File, expectedId: String): Pair<MotionProject, String> {
        require(file.isFile && !Files.isSymbolicLink(file.toPath())) { "Arquivo de projeto inválido" }
        require(file.length() <= ProjectLimits.MAX_SERIALIZED_BYTES) { "Projeto excede o limite de 16 MiB" }
        // Bounded read even when another process changes the file after the size check.
        val source = file.inputStream().use { input ->
            val output = java.io.ByteArrayOutputStream()
            val buffer = ByteArray(8192)
            var total = 0
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                total += count
                require(total <= ProjectLimits.MAX_SERIALIZED_BYTES) { "Projeto excede o limite de 16 MiB" }
                output.write(buffer, 0, count)
            }
            output.toString(Charsets.UTF_8.name())
        }
        val project = ProjectCodec.decode(source)
        require(project.id == expectedId) { "Identificador do arquivo não corresponde ao projeto" }
        return project to source
    }

    private fun writeAtomically(file: File, source: String) {
        val temporary = File.createTempFile(".openframe-", ".tmp", root)
        try {
            FileOutputStream(temporary).use { output ->
                output.write(source.toByteArray(Charsets.UTF_8))
                output.fd.sync()
            }
            try {
                Files.move(temporary.toPath(), file.toPath(), StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING)
            } catch (_: AtomicMoveNotSupportedException) {
                Files.move(temporary.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING)
            }
        } finally {
            temporary.delete()
        }
    }

    private fun report(id: String, kind: ProjectDiagnosticKind, message: String) {
        issues.removeAll { it.projectId == id && it.kind == kind }
        issues += ProjectDiagnostic(id, kind, message)
    }

    companion object {
        const val SUFFIX = ".ofm.json"
        private const val BACKUP_SUFFIX = ".bak"
    }
}
