// SPDX-License-Identifier: GPL-3.0-or-later
package org.openframe.persistence

import kotlinx.serialization.SerializationException
import kotlinx.serialization.json.*
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test
import org.openframe.model.*

class ProjectCodecTest {
    @Test fun roundTripsEveryLayerTypeAndAnimatedProperty() {
        val project = MotionProject(
            name = "Composição • ação 🎬",
            layers = listOf(
                Layer(shape = ShapeKind.ELLIPSE, tracks = AnimatedProperty.entries.map { property ->
                    AnimationTrack(property, listOf(
                        Keyframe(0, 0.25f, Easing.CUBIC_BEZIER, BezierCurve(0.2f, -0.3f, 0.9f, 1.3f)),
                        Keyframe(4000, 0.75f, Easing.HOLD),
                    ))
                }),
                Layer(type = LayerType.TEXT, text = "Olá\nOpenFrame", color = 0x80FFAA00L),
                Layer(type = LayerType.IMAGE, mediaRef = "photo-123.webp"),
            ),
        )
        val source = ProjectCodec.encode(project)
        assertTrue(source.contains("\"schemaVersion\": 1"))
        assertEquals(project, ProjectCodec.decode(source))
    }

    @Test fun refusesFutureSchemaInsteadOfDroppingUnsupportedContent() {
        val encoded = ProjectCodec.encode(MotionProject()).replace("\"schemaVersion\": 1", "\"schemaVersion\": 2")
        val exception = assertThrows(UnsupportedProjectVersionException::class.java) { ProjectCodec.decode(encoded) }
        assertEquals(2, exception.version)
    }

    @Test fun refusesMissingVersionAndTruncatedJson() {
        assertThrows(UnsupportedProjectVersionException::class.java) { ProjectCodec.decode("{}") }
        assertThrows(SerializationException::class.java) { ProjectCodec.decode("{\"schemaVersion\":1,") }
    }

    @Test fun missingRequiredFieldsDoNotInventAProject() {
        assertThrows(SerializationException::class.java) { ProjectCodec.decode("{\"schemaVersion\":1,\"id\":\"p\"}") }
    }

    @Test fun missingLayerIdentityIsRejectedRatherThanRandomlyRegenerated() {
        val document = Json.parseToJsonElement(ProjectCodec.encode(MotionProject(layers = listOf(Layer())))).jsonObject
        val incompleteLayer = JsonObject(document.getValue("layers").jsonArray.single().jsonObject - "id")
        val invalid = JsonObject(document + ("layers" to JsonArray(listOf(incompleteLayer))))
        assertThrows(SerializationException::class.java) { ProjectCodec.decode(invalid.toString()) }
    }

    @Test fun toleratesAdditionalMetadataWithinTheSameSchema() {
        val project = MotionProject()
        val source = ProjectCodec.encode(project).replaceFirst("{", "{\"comment\":\"portable metadata\",")
        assertEquals(project, ProjectCodec.decode(source))
    }

    @Test fun rejectsMalformedPersistedValues() {
        val source = ProjectCodec.encode(MotionProject()).replace("\"fps\": 30", "\"fps\": 240")
        assertThrows(IllegalArgumentException::class.java) { ProjectCodec.decode(source) }
    }
}
