// SPDX-License-Identifier: GPL-3.0-or-later
package org.openframe.persistence

import java.io.File
import java.io.FileNotFoundException
import java.io.IOException
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import org.openframe.model.*

class ProjectStoreTest {
    @get:Rule val temporary = TemporaryFolder()

    @Test fun savedProjectCanBeReopenedByAnotherStore() {
        val directory = temporary.newFolder()
        val project = MotionProject(layers = listOf(Layer(type = LayerType.TEXT, text = "Persistência")))
        ProjectStore(directory).save(project)
        assertEquals(project, ProjectStore(directory).load(project.id))
    }

    @Test fun latestRevisionAndListOrderingArePreserved() {
        val store = ProjectStore(temporary.newFolder())
        val first = MotionProject(updatedAt = 100)
        val second = MotionProject(updatedAt = 200)
        store.save(first)
        store.save(second)
        val updated = first.copy(name = "Revisão nova", updatedAt = 300)
        store.save(updated)
        assertEquals(listOf(updated, second), store.list())
    }

    @Test fun duplicateCreatesNewPersistentProjectAndLayerIds() {
        val store = ProjectStore(temporary.newFolder())
        val project = MotionProject(name = "A".repeat(120), layers = listOf(
            Layer(type = LayerType.IMAGE, mediaRef = "shared.png"),
            Layer(tracks = listOf(AnimationTrack(AnimatedProperty.X, listOf(Keyframe(0, 1f))))),
        ))
        store.save(project)
        val copy = store.duplicate(project.id)
        assertNotEquals(project.id, copy.id)
        assertEquals(120, copy.name.length)
        assertTrue(project.layers.map { it.id }.intersect(copy.layers.map { it.id }.toSet()).isEmpty())
        assertEquals(project.layers.first().mediaRef, copy.layers.first().mediaRef)
        assertEquals(project.layers.last().tracks, copy.layers.last().tracks)
        assertEquals(copy, store.load(copy.id))
        assertEquals(project, store.load(project.id))
    }

    @Test fun truncatedCurrentRevisionRecoversThePreviousCommittedRevision() {
        val directory = temporary.newFolder()
        val store = ProjectStore(directory)
        val old = MotionProject(name = "Anterior")
        store.save(old)
        store.save(old.copy(name = "Atual"))
        File(directory, old.id + ProjectStore.SUFFIX).writeText("{\"schemaVersion\":1,")
        assertEquals(old, store.load(old.id))
        assertEquals(ProjectDiagnosticKind.RECOVERED_FROM_BACKUP, store.diagnostics.single().kind)
        assertEquals(old, ProjectStore(directory).load(old.id))
    }

    @Test fun backupOnlyProjectsRecoverAfterMissingPrimary() {
        val directory = temporary.newFolder()
        val store = ProjectStore(directory)
        val project = MotionProject()
        store.save(project)
        store.save(project.copy(name = "Revisão 2"))
        assertTrue(File(directory, project.id + ProjectStore.SUFFIX).delete())
        assertEquals(listOf(project), store.list())
        assertTrue(File(directory, project.id + ProjectStore.SUFFIX).isFile)
    }

    @Test fun oneCorruptProjectDoesNotHideOtherProjectsOrGetDeleted() {
        val directory = temporary.newFolder()
        val store = ProjectStore(directory)
        val good = MotionProject()
        store.save(good)
        val broken = File(directory, "broken" + ProjectStore.SUFFIX).apply { writeText("{broken") }
        assertEquals(listOf(good), store.list())
        assertEquals("broken", store.diagnostics.single().projectId)
        assertEquals("{broken", broken.readText())
    }

    @Test fun futureVersionIsNeverReplacedByAnOlderBackupOrSave() {
        val directory = temporary.newFolder()
        val store = ProjectStore(directory)
        val project = MotionProject()
        store.save(project)
        store.save(project.copy(name = "New"))
        val file = File(directory, project.id + ProjectStore.SUFFIX)
        val future = file.readText().replace("\"schemaVersion\": 1", "\"schemaVersion\": 99")
        file.writeText(future)
        assertThrows(UnsupportedProjectVersionException::class.java) { store.load(project.id) }
        assertThrows(UnsupportedProjectVersionException::class.java) { store.save(project) }
        assertTrue(store.list().isEmpty())
        assertEquals(ProjectDiagnosticKind.UNSUPPORTED_VERSION, store.diagnostics.single().kind)
        assertEquals(future, file.readText())
    }

    @Test fun corruptPrimaryNeverOverwritesGoodBackupDuringSave() {
        val directory = temporary.newFolder()
        val store = ProjectStore(directory)
        val original = MotionProject()
        store.save(original)
        store.save(original.copy(name = "Second"))
        File(directory, original.id + ProjectStore.SUFFIX).writeText("truncated")
        store.save(original.copy(name = "Third"))
        File(directory, original.id + ProjectStore.SUFFIX).writeText("truncated again")
        assertEquals(original, store.load(original.id))
    }

    @Test fun mismatchedIdsAndUnsafeLookupAreRejected() {
        val directory = temporary.newFolder()
        val store = ProjectStore(directory)
        val project = MotionProject(id = "actual")
        File(directory, "wrong" + ProjectStore.SUFFIX).writeText(ProjectCodec.encode(project))
        assertThrows(IOException::class.java) { store.load("wrong") }
        assertThrows(IllegalArgumentException::class.java) { store.load("../escape") }
        assertThrows(IllegalArgumentException::class.java) { store.delete("../escape") }
    }

    @Test fun deletingRemovesBothRevisionsSoListCannotResurrectProject() {
        val directory = temporary.newFolder()
        val store = ProjectStore(directory)
        val project = MotionProject()
        store.save(project)
        store.save(project.copy(name = "Changed"))
        store.delete(project.id)
        assertTrue(store.list().isEmpty())
        assertThrows(FileNotFoundException::class.java) { store.load(project.id) }
        assertTrue(directory.listFiles()!!.isEmpty())
    }

    @Test fun incompleteTemporaryFilesAreNeverListedAsProjects() {
        val directory = temporary.newFolder()
        File(directory, ".openframe-interrupted.tmp").writeText("partial")
        val store = ProjectStore(directory)
        assertTrue(store.list().isEmpty())
        assertTrue(store.diagnostics.isEmpty())
    }
}
