// SPDX-License-Identifier: GPL-3.0-or-later
package org.openframe.rendering

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.media.ExifInterface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.util.LruCache
import org.openframe.animation.AnimationEngine
import org.openframe.model.Layer
import org.openframe.model.LayerType
import org.openframe.model.MotionProject
import org.openframe.model.ShapeKind
import java.io.Closeable
import java.io.File
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Deterministic reference compositor used by preview, thumbnails and export.
 * Calls are serialized. Keep one renderer per rendering job and close it when the job ends.
 * Canvas software is the initial backend; effects/GPU composition can replace this class later.
 */
class CompositionRenderer(
    private val mediaDirectory: File,
    private val maxImageEdge: Int = 2048,
    cacheBytes: Int = 32 * 1024 * 1024,
) : Closeable {
    init {
        require(maxImageEdge in 128..2048 && cacheBytes > 0)
    }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val imageCache = object : LruCache<String, Bitmap>(cacheBytes) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.allocationByteCount
    }
    private val textCache = object : LruCache<TextKey, StaticLayout>(32) {}
    private val unavailable = linkedSetOf<String>()
    private var closed = false

    /** Missing or invalid image references encountered in the most recent frame. */
    val missingMedia: Set<String> @Synchronized get() = unavailable.toSet()

    @Synchronized
    fun render(canvas: Canvas, project: MotionProject, timeMs: Long, width: Int, height: Int) {
        check(!closed) { "Renderer fechado" }
        require(width > 0 && height > 0 && project.width > 0 && project.height > 0)
        unavailable.clear()
        canvas.drawColor(Color.BLACK)
        val fit = min(width.toFloat() / project.width, height.toFloat() / project.height)
        val checkpoint = canvas.save()
        try {
            canvas.translate((width - project.width * fit) / 2f, (height - project.height * fit) / 2f)
            canvas.scale(fit, fit)
            canvas.clipRect(0f, 0f, project.width.toFloat(), project.height.toFloat())
            canvas.drawColor(project.backgroundColor.toInt() or (0xFF shl 24))
            for (layer in project.layers) {
                if (layer.isActive(timeMs)) drawLayer(canvas, layer, timeMs)
            }
        } finally {
            canvas.restoreToCount(checkpoint)
        }
    }

    @Synchronized
    fun renderBitmap(project: MotionProject, timeMs: Long, width: Int, height: Int): Bitmap {
        require(width in 1..4096 && height in 1..4096) { "Tamanho de renderização inválido" }
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        try {
            render(Canvas(bitmap), project, timeMs, width, height)
            return bitmap
        } catch (failure: Throwable) {
            bitmap.recycle()
            throw failure
        }
    }

    private fun drawLayer(canvas: Canvas, layer: Layer, timeMs: Long) {
        val transform = AnimationEngine.evaluate(layer, timeMs)
        val opacity = transform.opacity.coerceIn(0f, 1f)
        if (opacity <= 0f || layer.width <= 0f || layer.height <= 0f) return
        val checkpoint = canvas.save()
        try {
            canvas.translate(transform.x, transform.y)
            canvas.rotate(transform.rotation)
            canvas.scale(transform.scaleX, transform.scaleY)
            canvas.translate(-layer.width * transform.anchorX, -layer.height * transform.anchorY)
            paint.style = Paint.Style.FILL
            paint.color = layer.color.toInt()
            paint.alpha = (Color.alpha(layer.color.toInt()) * opacity).roundToInt()
            when (layer.type) {
                LayerType.SHAPE -> when (layer.shape) {
                    ShapeKind.RECTANGLE -> canvas.drawRect(0f, 0f, layer.width, layer.height, paint)
                    ShapeKind.ELLIPSE -> canvas.drawOval(0f, 0f, layer.width, layer.height, paint)
                }
                LayerType.TEXT -> drawText(canvas, layer, opacity)
                LayerType.IMAGE -> drawImage(canvas, layer, opacity)
            }
        } finally {
            canvas.restoreToCount(checkpoint)
        }
    }

    private fun drawText(canvas: Canvas, layer: Layer, opacity: Float) {
        val key = TextKey(layer.text, layer.width.roundToInt().coerceIn(1, 16384), layer.fontSize, layer.color.toInt())
        val layout = textCache.get(key) ?: run {
            val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = key.color
                textSize = key.size
                typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL)
            }
            StaticLayout.Builder.obtain(key.text, 0, key.text.length, textPaint, key.width)
                .setAlignment(Layout.Alignment.ALIGN_CENTER)
                .setIncludePad(false)
                .setMaxLines(100)
                .build().also { textCache.put(key, it) }
        }
        layout.paint.alpha = (Color.alpha(layer.color.toInt()) * opacity).roundToInt()
        canvas.clipRect(0f, 0f, layer.width, layer.height)
        canvas.translate(0f, (layer.height - layout.height) / 2f)
        layout.draw(canvas)
    }

    private fun drawImage(canvas: Canvas, layer: Layer, opacity: Float) {
        val ref = layer.mediaRef
        val bitmap = ref?.let { loadImage(it) }
        if (bitmap == null) {
            unavailable += ref ?: "${layer.name}: sem referência"
            paint.color = Color.rgb(104, 34, 54)
            paint.alpha = (255 * opacity).roundToInt()
            canvas.drawRect(0f, 0f, layer.width, layer.height, paint)
            paint.color = Color.rgb(255, 160, 174)
            paint.strokeWidth = min(layer.width, layer.height) * 0.025f
            canvas.drawLine(0f, 0f, layer.width, layer.height, paint)
            canvas.drawLine(layer.width, 0f, 0f, layer.height, paint)
            return
        }
        val fit = min(layer.width / bitmap.width, layer.height / bitmap.height)
        val w = bitmap.width * fit
        val h = bitmap.height * fit
        paint.color = Color.WHITE
        paint.alpha = (255 * opacity).roundToInt()
        canvas.drawBitmap(bitmap, null, RectF((layer.width - w) / 2f, (layer.height - h) / 2f,
            (layer.width + w) / 2f, (layer.height + h) / 2f), paint)
    }

    private fun loadImage(ref: String): Bitmap? {
        if (ref.isBlank() || ref != File(ref).name || ref == "." || ref == ".." || ref.contains('\\')) return null
        return try {
            val file = File(mediaDirectory, ref)
            if (!file.isFile || file.length() > 64L * 1024 * 1024) return null
            if (file.canonicalFile.parentFile != mediaDirectory.canonicalFile) return null
            val cacheKey = "$ref:${file.lastModified()}:${file.length()}"
            imageCache.get(cacheKey)?.let { return it }
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.path, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
            var sample = 1
            while (bounds.outWidth / sample > maxImageEdge || bounds.outHeight / sample > maxImageEdge) sample *= 2
            val options = BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.ARGB_8888 }
            val decoded = BitmapFactory.decodeFile(file.path, options) ?: return null
            val orientation = runCatching {
                ExifInterface(file.path).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            }.getOrDefault(ExifInterface.ORIENTATION_NORMAL)
            val matrix = Matrix()
            when (orientation) {
                ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.setScale(-1f, 1f)
                ExifInterface.ORIENTATION_ROTATE_180 -> matrix.setRotate(180f)
                ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.setScale(1f, -1f)
                ExifInterface.ORIENTATION_TRANSPOSE -> { matrix.setRotate(90f); matrix.postScale(-1f, 1f) }
                ExifInterface.ORIENTATION_ROTATE_90 -> matrix.setRotate(90f)
                ExifInterface.ORIENTATION_TRANSVERSE -> { matrix.setRotate(270f); matrix.postScale(-1f, 1f) }
                ExifInterface.ORIENTATION_ROTATE_270 -> matrix.setRotate(270f)
            }
            val result = if (matrix.isIdentity) decoded else Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true)
            if (result !== decoded) decoded.recycle()
            imageCache.put(cacheKey, result)
            result
        } catch (_: Exception) {
            null
        } catch (_: OutOfMemoryError) {
            imageCache.evictAll()
            null
        }
    }

    @Synchronized
    override fun close() {
        if (closed) return
        closed = true
        // Do not recycle cached bitmaps: a hardware Canvas can still hold a display-list reference.
        imageCache.evictAll()
        textCache.evictAll()
        unavailable.clear()
    }

    private data class TextKey(val text: String, val width: Int, val size: Float, val color: Int)
}
