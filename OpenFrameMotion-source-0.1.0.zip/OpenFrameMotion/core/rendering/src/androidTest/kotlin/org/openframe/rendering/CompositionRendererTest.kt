// SPDX-License-Identifier: GPL-3.0-or-later
package org.openframe.rendering

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.*
import org.junit.Test
import org.openframe.model.*
import java.io.File

class CompositionRendererTest {
    private val mediaDirectory: File
        get() = File(InstrumentationRegistry.getInstrumentation().targetContext.cacheDir, "renderer-test-media").apply { mkdirs() }

    @Test fun layerOrderOpacityAndTimeAreAppliedToPixels() {
        val back = Layer(width = 64f, height = 64f, color = 0xFFFF0000,
            transform = Transform(x = 32f, y = 32f))
        val front = Layer(width = 32f, height = 32f, color = 0xFF0000FF,
            startMs = 100, durationMs = 200, transform = Transform(x = 32f, y = 32f, opacity = 0.5f))
        val project = MotionProject(width = 64, height = 64, backgroundColor = 0xFF000000, layers = listOf(back, front))
        CompositionRenderer(mediaDirectory).use { renderer ->
            renderer.renderBitmap(project, 0, 64, 64).useBitmap { assertEquals(Color.RED, it.getPixel(32, 32)) }
            renderer.renderBitmap(project, 100, 64, 64).useBitmap {
                val pixel = it.getPixel(32, 32)
                assertTrue(kotlin.math.abs(127 - Color.red(pixel)) <= 1)
                assertTrue(kotlin.math.abs(128 - Color.blue(pixel)) <= 1)
                assertEquals(Color.RED, it.getPixel(5, 5))
            }
            renderer.renderBitmap(project, 300, 64, 64).useBitmap { assertEquals(Color.RED, it.getPixel(32, 32)) }
        }
    }

    @Test fun evaluatorDrivesLayerPositionRelativeToLayerStart() {
        val layer = Layer(startMs = 100, durationMs = 1000, width = 10f, height = 10f, color = 0xFF00FF00,
            transform = Transform(x = 10f, y = 32f),
            tracks = listOf(AnimationTrack(AnimatedProperty.X, listOf(Keyframe(0, 10f), Keyframe(1000, 54f)))))
        val project = MotionProject(width = 64, height = 64, backgroundColor = 0xFF000000, layers = listOf(layer))
        CompositionRenderer(mediaDirectory).use { renderer ->
            renderer.renderBitmap(project, 600, 64, 64).useBitmap {
                assertEquals(Color.GREEN, it.getPixel(32, 32))
                assertEquals(Color.BLACK, it.getPixel(10, 32))
            }
        }
    }

    @Test fun bitmapAndCanvasEntryPointsProduceIdenticalComposition() {
        val project = MotionProject(width = 128, height = 64, backgroundColor = 0xFF112233,
            layers = listOf(Layer(width = 35f, height = 18f, shape = ShapeKind.ELLIPSE,
                transform = Transform(x = 60f, y = 30f, rotation = 24f))))
        CompositionRenderer(mediaDirectory).use { renderer ->
            val expected = renderer.renderBitmap(project, 250, 128, 128)
            val actual = Bitmap.createBitmap(128, 128, Bitmap.Config.ARGB_8888)
            try {
                renderer.render(Canvas(actual), project, 250, 128, 128)
                assertTrue(expected.sameAs(actual))
                assertEquals(Color.BLACK, actual.getPixel(64, 5)) // Letterbox, not stretched.
            } finally { expected.recycle(); actual.recycle() }
        }
    }

    @Test fun importedImageKeepsAspectAndUnsafeReferenceIsReported() {
        val image = Bitmap.createBitmap(40, 20, Bitmap.Config.ARGB_8888).apply { eraseColor(Color.YELLOW) }
        val file = File(mediaDirectory, "test.png")
        file.outputStream().use { image.compress(Bitmap.CompressFormat.PNG, 100, it) }
        image.recycle()
        try {
            val layer = Layer(type = LayerType.IMAGE, mediaRef = file.name, width = 64f, height = 64f,
                transform = Transform(x = 32f, y = 32f))
            val project = MotionProject(width = 64, height = 64, backgroundColor = 0xFF000000, layers = listOf(layer))
            CompositionRenderer(mediaDirectory).use { renderer ->
                renderer.renderBitmap(project, 0, 64, 64).useBitmap {
                    assertEquals(Color.YELLOW, it.getPixel(32, 32))
                    assertEquals(Color.BLACK, it.getPixel(32, 4))
                }
                assertTrue(renderer.missingMedia.isEmpty())
                renderer.renderBitmap(project.copy(layers = listOf(layer.copy(mediaRef = "../private.png"))), 0, 64, 64).recycle()
                assertEquals(setOf("../private.png"), renderer.missingMedia)
            }
        } finally { file.delete() }
    }

    private fun Bitmap.useBitmap(block: (Bitmap) -> Unit) = try { block(this) } finally { recycle() }
}
