// SPDX-License-Identifier: GPL-3.0-or-later
package org.openframe.animation

import org.openframe.model.AnimationTrack
import org.openframe.model.BezierCurve
import org.openframe.model.Easing
import org.openframe.model.Keyframe
import org.openframe.model.Layer
import org.openframe.model.Transform

/**
 * Pure time-based evaluation shared by preview and export.
 *
 * Track times are relative to the layer start. Before/after the first/last keyframe,
 * its value is held. The outgoing keyframe owns the easing of a segment. Unsorted
 * tracks are accepted; the last entry at a duplicate timestamp wins. Duplicate
 * property tracks similarly use the last track in the layer. Project validation
 * rejects duplicate property tracks on disk, but this policy makes interactive
 * evaluation deterministic too.
 *
 * Visibility and layer duration are composition concerns, so [evaluate] evaluates
 * even an inactive layer (useful to inspect its properties). Rotation interpolates
 * the specified angles without wrapping, allowing deliberate multiple revolutions.
 */
object AnimationEngine {
    private val easeIn = BezierCurve(0.42f, 0f, 1f, 1f)
    private val easeOut = BezierCurve(0f, 0f, 0.58f, 1f)
    private val easeInOut = BezierCurve(0.42f, 0f, 0.58f, 1f)

    fun evaluate(layer: Layer, projectTimeMs: Long): Transform {
        // Valid project/layer times are non-negative, so this avoids subtraction
        // overflow for callers inspecting a time before the project starts.
        val localTime = if (projectTimeMs <= layer.startMs) 0L else projectTimeMs - layer.startMs
        var result = layer.transform
        for (track in layer.tracks) {
            result = result.withValue(
                track.property,
                evaluateTrack(track, localTime, layer.transform.value(track.property)),
            )
        }
        return result
    }

    fun evaluateTrack(track: AnimationTrack, localTimeMs: Long, defaultValue: Float): Float {
        require(defaultValue.isFinite()) { "The default animation value must be finite" }
        // Find the surrounding keys without allocating/sorting on every frame.
        // <= / >= deliberately replace the old candidate at a duplicate time.
        var before: Keyframe? = null
        var after: Keyframe? = null
        for (keyframe in track.keyframes) {
            require(keyframe.value.isFinite()) { "Keyframe values must be finite" }
            if (keyframe.timeMs <= localTimeMs && (before == null || keyframe.timeMs >= before.timeMs)) {
                before = keyframe
            }
            if (keyframe.timeMs > localTimeMs && (after == null || keyframe.timeMs <= after.timeMs)) {
                after = keyframe
            }
        }
        val start = before ?: return after?.value ?: defaultValue
        val end = after ?: return start.value
        if (start.timeMs == localTimeMs) return start.value
        // Compute differences in Double so large Long times cannot overflow.
        val fraction = ((localTimeMs.toDouble() - start.timeMs.toDouble()) /
            (end.timeMs.toDouble() - start.timeMs.toDouble())).toFloat()
        val amount = interpolate(fraction, start.easing, start.curve).toDouble()
        return (start.value.toDouble() + (end.value.toDouble() - start.value.toDouble()) * amount).toFloat()
    }

    /** Easing maps elapsed segment progress to value progress. Bézier y may overshoot. */
    fun interpolate(fraction: Float, easing: Easing, curve: BezierCurve = BezierCurve()): Float {
        require(fraction.isFinite()) { "Animation progress must be finite" }
        val progress = fraction.coerceIn(0f, 1f)
        if (progress == 0f || progress == 1f) return progress
        return when (easing) {
            Easing.LINEAR -> progress
            Easing.HOLD -> 0f
            Easing.EASE_IN -> cubicBezier(progress, easeIn)
            Easing.EASE_OUT -> cubicBezier(progress, easeOut)
            Easing.EASE_IN_OUT -> cubicBezier(progress, easeInOut)
            Easing.CUBIC_BEZIER -> cubicBezier(progress, curve)
        }
    }

    private fun cubicBezier(progress: Float, curve: BezierCurve): Float {
        require(curve.x1.isFinite() && curve.x1 in 0f..1f && curve.x2.isFinite() && curve.x2 in 0f..1f) {
            "Bézier x control points must be between zero and one"
        }
        require(curve.y1.isFinite() && curve.y2.isFinite()) { "Bézier y control points must be finite" }
        // Invert Bx(t)=progress. Bisection remains stable even when the derivative
        // is zero, unlike an unguarded Newton iteration, and has a fixed work bound.
        var low = 0.0
        var high = 1.0
        val x1 = curve.x1.toDouble()
        val x2 = curve.x2.toDouble()
        repeat(32) {
            val parameter = (low + high) * 0.5
            if (component(parameter, x1, x2) < progress.toDouble()) low = parameter else high = parameter
        }
        return component((low + high) * 0.5, curve.y1.toDouble(), curve.y2.toDouble()).toFloat()
    }

    private fun component(parameter: Double, control1: Double, control2: Double): Double {
        val inverse = 1.0 - parameter
        return 3.0 * inverse * inverse * parameter * control1 +
            3.0 * inverse * parameter * parameter * control2 + parameter * parameter * parameter
    }
}
