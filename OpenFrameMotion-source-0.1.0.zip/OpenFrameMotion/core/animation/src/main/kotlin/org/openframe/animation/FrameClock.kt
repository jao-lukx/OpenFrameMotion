// SPDX-License-Identifier: GPL-3.0-or-later
package org.openframe.animation

/** Rational frame times avoid accumulation of a truncated millisecond frame period. */
object FrameClock {
    fun frameCount(durationMs: Long, fps: Int): Long {
        require(durationMs in 1..60_000 && fps in 1..240)
        return (durationMs * fps + 999) / 1000
    }

    fun timeMs(frameIndex: Long, fps: Int): Long {
        require(frameIndex >= 0 && fps in 1..240)
        return frameIndex * 1000 / fps
    }

    fun snap(timeMs: Long, durationMs: Long, fps: Int): Long {
        val lastFrame = frameCount(durationMs, fps) - 1
        val nearestFrame = ((timeMs.coerceIn(0, durationMs - 1) * fps + 500) / 1000).coerceIn(0, lastFrame)
        return FrameClock.timeMs(nearestFrame, fps)
    }
}
