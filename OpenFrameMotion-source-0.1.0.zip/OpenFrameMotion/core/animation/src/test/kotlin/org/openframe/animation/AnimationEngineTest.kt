// SPDX-License-Identifier: GPL-3.0-or-later
package org.openframe.animation

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.openframe.model.AnimatedProperty
import org.openframe.model.AnimationTrack
import org.openframe.model.BezierCurve
import org.openframe.model.Easing
import org.openframe.model.Keyframe
import org.openframe.model.Layer
import org.openframe.model.Transform

class AnimationEngineTest {
    private fun track(vararg keys: Keyframe) = AnimationTrack(AnimatedProperty.X, keys.toList())

    @Test fun emptyTrackUsesDefaultValue() {
        assertEquals(12f, AnimationEngine.evaluateTrack(track(), 500, 12f), 0f)
    }

    @Test fun valuesAreHeldBeforeFirstAndAfterLastKeyframe() {
        val keys = track(Keyframe(500, 20f), Keyframe(1500, 60f))
        assertEquals(20f, AnimationEngine.evaluateTrack(keys, -100, 0f), 0f)
        assertEquals(20f, AnimationEngine.evaluateTrack(keys, 500, 0f), 0f)
        assertEquals(40f, AnimationEngine.evaluateTrack(keys, 1000, 0f), 0.0001f)
        assertEquals(60f, AnimationEngine.evaluateTrack(keys, 1500, 0f), 0f)
        assertEquals(60f, AnimationEngine.evaluateTrack(keys, Long.MAX_VALUE, 0f), 0f)
    }

    @Test fun unsortedTracksAndDuplicateTimesUseLastSerializedEntry() {
        val keys = track(Keyframe(1000, 100f), Keyframe(0, 0f), Keyframe(1000, 200f), Keyframe(0, 20f))
        assertEquals(20f, AnimationEngine.evaluateTrack(keys, -1, 0f), 0f)
        assertEquals(110f, AnimationEngine.evaluateTrack(keys, 500, 0f), 0.0001f)
        assertEquals(200f, AnimationEngine.evaluateTrack(keys, 1000, 0f), 0f)
    }

    @Test fun outgoingHoldDoesNotBlendAndNextKeyIsExact() {
        val keys = track(Keyframe(0, 20f, Easing.HOLD), Keyframe(1000, 80f))
        assertEquals(20f, AnimationEngine.evaluateTrack(keys, 999, 0f), 0f)
        assertEquals(80f, AnimationEngine.evaluateTrack(keys, 1000, 0f), 0f)
    }

    @Test fun layerStartOffsetsProjectTimeAndUnanimatedValuesArePreserved() {
        val layer = Layer(
            startMs = 2000,
            transform = Transform(y = 42f, rotation = 15f),
            tracks = listOf(track(Keyframe(0, 0f), Keyframe(1000, 100f))),
        )
        assertEquals(50f, AnimationEngine.evaluate(layer, 2500).x, 0.0001f)
        assertEquals(0f, AnimationEngine.evaluate(layer, Long.MIN_VALUE).x, 0f)
        assertEquals(42f, AnimationEngine.evaluate(layer, 2500).y, 0f)
        assertEquals(15f, AnimationEngine.evaluate(layer, 2500).rotation, 0f)
    }

    @Test fun allTransformChannelsAreEvaluatedAndOpacityIsClamped() {
        val tracks = AnimatedProperty.entries.map { property ->
            AnimationTrack(property, listOf(Keyframe(0, 0f), Keyframe(1000, 2f)))
        }
        val result = AnimationEngine.evaluate(Layer(tracks = tracks), 750)
        AnimatedProperty.entries.forEach { property ->
            assertEquals(if (property == AnimatedProperty.OPACITY) 1f else 1.5f, result.value(property), 0.0001f)
        }
    }

    @Test fun rotationKeepsExplicitMultipleRevolutions() {
        val layer = Layer(tracks = listOf(AnimationTrack(AnimatedProperty.ROTATION, listOf(Keyframe(0, 0f), Keyframe(1000, 720f)))))
        assertEquals(360f, AnimationEngine.evaluate(layer, 500).rotation, 0f)
    }

    @Test fun namedEasingsHaveKnownMidpointsAndSymmetry() {
        assertEquals(0.3153568f, AnimationEngine.interpolate(0.5f, Easing.EASE_IN), 0.00001f)
        assertEquals(0.6846432f, AnimationEngine.interpolate(0.5f, Easing.EASE_OUT), 0.00001f)
        assertEquals(0.5f, AnimationEngine.interpolate(0.5f, Easing.EASE_IN_OUT), 0.00001f)
        for (step in 0..100) {
            val progress = step / 100f
            assertEquals(1f, AnimationEngine.interpolate(progress, Easing.EASE_IN) +
                AnimationEngine.interpolate(1f - progress, Easing.EASE_OUT), 0.00001f)
        }
    }

    @Test fun bezierSolvesXInsteadOfTreatingElapsedTimeAsCurveParameter() {
        // Bx(t)=t^3, By(t)=3t^2-2t^3. At x=1/8, parameter=1/2 and y=1/2.
        val curve = BezierCurve(0f, 0f, 0f, 1f)
        assertEquals(0.5f, AnimationEngine.interpolate(0.125f, Easing.CUBIC_BEZIER, curve), 0.00001f)
    }

    @Test fun customCurveAllowsOvershootButIdentityRemainsLinear() {
        val identity = BezierCurve(0.25f, 0.25f, 0.75f, 0.75f)
        for (step in 0..100) {
            val progress = step / 100f
            assertEquals(progress, AnimationEngine.interpolate(progress, Easing.CUBIC_BEZIER, identity), 0.00001f)
        }
        val overshoot = BezierCurve(0.25f, 2f, 0.75f, 2f)
        assertTrue(AnimationEngine.interpolate(0.5f, Easing.CUBIC_BEZIER, overshoot) > 1f)
    }

    @Test fun outOfRangeProgressIsClampedWithExactEndpoints() {
        for (easing in Easing.entries) {
            assertEquals(0f, AnimationEngine.interpolate(-0.25f, easing), 0f)
            assertEquals(1f, AnimationEngine.interpolate(1.25f, easing), 0f)
        }
    }

    @Test fun repeatedEvaluationDoesNotDependOnCallOrder() {
        val keys = track(Keyframe(0, -50f, Easing.EASE_IN_OUT), Keyframe(2000, 150f))
        val expected = AnimationEngine.evaluateTrack(keys, 1500, 0f)
        for (time in 2000 downTo 0 step 7) AnimationEngine.evaluateTrack(keys, time.toLong(), 0f)
        assertEquals(expected, AnimationEngine.evaluateTrack(keys, 1500, 0f), 0f)
    }

    @Test(expected = IllegalArgumentException::class) fun nonFiniteProgressIsRejected() {
        AnimationEngine.interpolate(Float.NaN, Easing.LINEAR)
    }

    @Test(expected = IllegalArgumentException::class) fun invalidBezierControlPointIsRejected() {
        AnimationEngine.interpolate(0.5f, Easing.CUBIC_BEZIER, BezierCurve(x1 = -1f))
    }
}
