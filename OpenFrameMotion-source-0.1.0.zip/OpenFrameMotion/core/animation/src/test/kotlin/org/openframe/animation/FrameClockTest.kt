// SPDX-License-Identifier: GPL-3.0-or-later
package org.openframe.animation

import org.junit.Assert.*
import org.junit.Test

class FrameClockTest {
    @Test fun snappingAnExistingFrameNeverMovesItBackwards() {
        for (fps in listOf(24, 25, 30, 60)) {
            for (index in 0 until FrameClock.frameCount(60_000, fps)) {
                val time = FrameClock.timeMs(index, fps)
                assertEquals("fps=$fps frame=$index", time, FrameClock.snap(time, 60_000, fps))
            }
        }
    }

    @Test fun endNeverSelectsAnInvisibleFrame() {
        assertEquals(4966L, FrameClock.snap(5000, 5000, 30))
        assertEquals(0L, FrameClock.snap(1, 1, 60))
        assertEquals(0L, FrameClock.snap(-10, 5000, 30))
    }

    @Test fun nonIntegralDurationIncludesItsLastFrame() {
        assertEquals(31L, FrameClock.frameCount(1001, 30))
        assertEquals(1000L, FrameClock.snap(1000, 1001, 30))
    }
}
