// SPDX-License-Identifier: GPL-3.0-or-later
package org.openframe.model

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertSame
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test

class ValidationTest {
    @Test fun acceptsDefaultProjectWithoutChangingComposition() {
        val project = MotionProject(layers = listOf(Layer()))
        assertSame(project, project.validated())
    }

    @Test fun timelineUsesHalfOpenVisibilityIntervals() {
        val layer = Layer(startMs = 100, durationMs = 200)
        assertFalse(layer.isActive(99))
        assertTrue(layer.isActive(100))
        assertTrue(layer.isActive(299))
        assertFalse(layer.isActive(300))
        assertFalse(layer.copy(visible = false).isActive(150))
    }

    @Test fun rejectsTraversalAndEmptyIdentifiers() {
        listOf("", "../escape", "/absolute", "a/b", "a\\b", "..", "a\u0000b").forEach { id ->
            assertFalse(isValidProjectId(id))
            assertThrows(IllegalArgumentException::class.java) { MotionProject(id = id).validated() }
        }
        assertTrue(isValidProjectId("4a87cc4f-05df-43c6-959b-911a904ecf4c"))
        assertTrue(isValidMediaReference("image-a.webp"))
        assertFalse(isValidMediaReference("../image.webp"))
        assertFalse(isValidMediaReference("content://provider/image"))
    }

    @Test fun rejectsOutOfBoundsTimelineAndOverflow() {
        listOf(Layer(startMs = -1), Layer(startMs = 5000), Layer(startMs = 1), Layer(durationMs = Long.MAX_VALUE)).forEach {
            assertThrows(IllegalArgumentException::class.java) { MotionProject(layers = listOf(it)).validated() }
        }
    }

    @Test fun requiresUniqueLayerAndTrackIds() {
        val layer = Layer()
        assertThrows(IllegalArgumentException::class.java) { MotionProject(layers = listOf(layer, layer)).validated() }
        val track = AnimationTrack(AnimatedProperty.X)
        assertThrows(IllegalArgumentException::class.java) {
            MotionProject(layers = listOf(layer.copy(tracks = listOf(track, track)))).validated()
        }
    }

    @Test fun rejectsNonFiniteAndInvalidPropertyValues() {
        listOf(
            Transform(x = Float.NaN),
            Transform(rotation = Float.POSITIVE_INFINITY),
            Transform(opacity = 1.01f),
            Transform(scaleX = 101f),
        ).forEach {
            assertThrows(IllegalArgumentException::class.java) { MotionProject(layers = listOf(Layer(transform = it))).validated() }
        }
    }

    @Test fun rejectsUnsortedDuplicateAndOutOfRangeKeyframes() {
        listOf(
            listOf(Keyframe(200, 1f), Keyframe(100, 2f)),
            listOf(Keyframe(100, 1f), Keyframe(100, 2f)),
            listOf(Keyframe(-1, 1f)),
            listOf(Keyframe(5001, 1f)),
        ).forEach { frames ->
            assertThrows(IllegalArgumentException::class.java) {
                MotionProject(layers = listOf(Layer(tracks = listOf(AnimationTrack(AnimatedProperty.X, frames))))).validated()
            }
        }
    }

    @Test fun acceptsBezierOvershootButRejectsNonMonotonicTimeCoordinates() {
        val frame = Keyframe(0, 1f, Easing.CUBIC_BEZIER, BezierCurve(0.4f, -0.5f, 0.6f, 1.5f))
        val project = MotionProject(layers = listOf(Layer(tracks = listOf(AnimationTrack(AnimatedProperty.X, listOf(frame))))))
        assertEquals(project, project.validated())
        val invalidFrame = frame.copy(curve = BezierCurve(x1 = -1f))
        val invalidTrack = AnimationTrack(AnimatedProperty.X, listOf(invalidFrame))
        assertThrows(IllegalArgumentException::class.java) {
            project.copy(layers = listOf(Layer(tracks = listOf(invalidTrack)))).validated()
        }
    }

    @Test fun enforcesDeviceResourceLimits() {
        assertThrows(IllegalArgumentException::class.java) { MotionProject(width = 4097).validated() }
        assertThrows(IllegalArgumentException::class.java) { MotionProject(height = 1).validated() }
        assertThrows(IllegalArgumentException::class.java) { MotionProject(fps = 120).validated() }
        assertThrows(IllegalArgumentException::class.java) { MotionProject(durationMs = 60_001).validated() }
        assertThrows(IllegalArgumentException::class.java) { MotionProject(layers = List(65) { Layer() }).validated() }
        assertThrows(IllegalArgumentException::class.java) {
            MotionProject(layers = listOf(Layer(tracks = listOf(AnimationTrack(AnimatedProperty.X,
                List(257) { Keyframe(it.toLong(), it.toFloat()) }))))).validated()
        }
    }

    @Test fun requiresMediaForImageAndAnOpaqueBackground() {
        assertThrows(IllegalArgumentException::class.java) { MotionProject(layers = listOf(Layer(type = LayerType.IMAGE))).validated() }
        assertThrows(IllegalArgumentException::class.java) { MotionProject(backgroundColor = 0x00112233L).validated() }
    }
}
