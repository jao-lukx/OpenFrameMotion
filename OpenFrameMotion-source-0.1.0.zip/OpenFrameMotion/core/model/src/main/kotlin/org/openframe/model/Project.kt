// SPDX-License-Identifier: GPL-3.0-or-later
package org.openframe.model

import kotlinx.serialization.Serializable
import java.util.UUID

const val CURRENT_SCHEMA_VERSION = 1
fun newId(): String = UUID.randomUUID().toString()

@Serializable
data class MotionProject(
    val schemaVersion: Int = CURRENT_SCHEMA_VERSION,
    val id: String = newId(),
    val name: String = "Novo projeto",
    val width: Int = 1080,
    val height: Int = 1920,
    val fps: Int = 30,
    val durationMs: Long = 5000,
    val backgroundColor: Long = 0xFF10131AL,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = createdAt,
    // Back to front. List order is the single source of truth for z order.
    val layers: List<Layer> = emptyList(),
)

@Serializable enum class LayerType { SHAPE, TEXT, IMAGE }
@Serializable enum class ShapeKind { RECTANGLE, ELLIPSE }
@Serializable enum class AnimatedProperty { X, Y, SCALE_X, SCALE_Y, ROTATION, OPACITY, ANCHOR_X, ANCHOR_Y }
@Serializable enum class Easing { LINEAR, EASE_IN, EASE_OUT, EASE_IN_OUT, HOLD, CUBIC_BEZIER }

@Serializable
data class BezierCurve(val x1: Float = 0.42f, val y1: Float = 0f, val x2: Float = 0.58f, val y2: Float = 1f)

@Serializable
data class Keyframe(val timeMs: Long, val value: Float, val easing: Easing = Easing.LINEAR, val curve: BezierCurve = BezierCurve())

@Serializable
data class AnimationTrack(val property: AnimatedProperty, val keyframes: List<Keyframe> = emptyList())

@Serializable
data class Transform(
    val x: Float = 540f,
    val y: Float = 960f,
    val scaleX: Float = 1f,
    val scaleY: Float = 1f,
    val rotation: Float = 0f,
    val opacity: Float = 1f,
    val anchorX: Float = 0.5f,
    val anchorY: Float = 0.5f,
) {
    fun value(property: AnimatedProperty): Float = when (property) {
        AnimatedProperty.X -> x
        AnimatedProperty.Y -> y
        AnimatedProperty.SCALE_X -> scaleX
        AnimatedProperty.SCALE_Y -> scaleY
        AnimatedProperty.ROTATION -> rotation
        AnimatedProperty.OPACITY -> opacity
        AnimatedProperty.ANCHOR_X -> anchorX
        AnimatedProperty.ANCHOR_Y -> anchorY
    }

    fun withValue(property: AnimatedProperty, value: Float): Transform = when (property) {
        AnimatedProperty.X -> copy(x = value)
        AnimatedProperty.Y -> copy(y = value)
        AnimatedProperty.SCALE_X -> copy(scaleX = value)
        AnimatedProperty.SCALE_Y -> copy(scaleY = value)
        AnimatedProperty.ROTATION -> copy(rotation = value)
        AnimatedProperty.OPACITY -> copy(opacity = value.coerceIn(0f, 1f))
        AnimatedProperty.ANCHOR_X -> copy(anchorX = value)
        AnimatedProperty.ANCHOR_Y -> copy(anchorY = value)
    }
}

@Serializable
data class Layer(
    val id: String = newId(),
    val name: String = "Forma",
    val type: LayerType = LayerType.SHAPE,
    val startMs: Long = 0,
    val durationMs: Long = 5000,
    val visible: Boolean = true,
    val transform: Transform = Transform(),
    val width: Float = 320f,
    val height: Float = 320f,
    val color: Long = 0xFF75E2C0L,
    val shape: ShapeKind = ShapeKind.RECTANGLE,
    val text: String = "OpenFrame",
    val fontSize: Float = 96f,
    // Basename in the app-private media directory. Never an arbitrary filesystem path.
    val mediaRef: String? = null,
    // Time is relative to the beginning of this layer.
    val tracks: List<AnimationTrack> = emptyList(),
) {
    fun isActive(timeMs: Long): Boolean = visible && timeMs >= startMs && timeMs - startMs < durationMs
}
