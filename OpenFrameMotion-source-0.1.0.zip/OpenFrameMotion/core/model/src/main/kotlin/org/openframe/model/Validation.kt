// SPDX-License-Identifier: GPL-3.0-or-later
package org.openframe.model

import kotlin.math.abs

object ProjectLimits {
    const val MAX_DURATION_MS = 60_000L
    const val MAX_LAYERS = 64
    const val MAX_KEYFRAMES_PER_TRACK = 256
    const val MAX_SERIALIZED_BYTES = 16 * 1024 * 1024
    val SUPPORTED_FPS: Set<Int> = setOf(24, 25, 30, 60)
}

private val identifier = Regex("[A-Za-z0-9][A-Za-z0-9_-]{0,127}")
private val assetBasename = Regex("[A-Za-z0-9][A-Za-z0-9._-]{0,191}")

fun isValidProjectId(value: String): Boolean = identifier.matches(value)

fun isValidMediaReference(value: String): Boolean = assetBasename.matches(value)

/** Reject invalid state instead of silently changing the user's composition. */
fun MotionProject.validated(): MotionProject {
    require(schemaVersion == CURRENT_SCHEMA_VERSION) { "Versão de projeto não suportada: $schemaVersion" }
    require(isValidProjectId(id)) { "Identificador de projeto inválido" }
    require(name.isNotBlank() && name.length <= 120) { "O nome deve ter entre 1 e 120 caracteres" }
    require(width in 64..4096 && height in 64..4096) { "A resolução deve estar entre 64 e 4096 pixels" }
    require(fps in ProjectLimits.SUPPORTED_FPS) { "FPS não suportado: $fps" }
    require(durationMs in 1..ProjectLimits.MAX_DURATION_MS) { "A duração deve ser de até 60 segundos" }
    require(backgroundColor in 0..0xFFFFFFFFL && backgroundColor ushr 24 == 255L) { "O fundo deve ser uma cor ARGB opaca" }
    require(createdAt >= 0 && updatedAt >= 0) { "Datas de projeto inválidas" }
    require(layers.size <= ProjectLimits.MAX_LAYERS) { "Limite de 64 camadas excedido" }
    require(layers.map { it.id }.distinct().size == layers.size) { "Identificadores de camada duplicados" }
    layers.forEach { layer ->
        require(isValidProjectId(layer.id)) { "Identificador de camada inválido" }
        require(layer.name.isNotBlank() && layer.name.length <= 120) { "Nome de camada inválido" }
        require(layer.startMs in 0 until durationMs) { "Início de camada fora do projeto" }
        // Subtraction avoids overflow on malformed Long values.
        require(layer.durationMs in 1..(durationMs - layer.startMs)) { "Duração de camada fora do projeto" }
        require(layer.width.isFinite() && layer.width > 0f && layer.width <= 8192f) { "Largura de camada inválida" }
        require(layer.height.isFinite() && layer.height > 0f && layer.height <= 8192f) { "Altura de camada inválida" }
        require(layer.color in 0..0xFFFFFFFFL) { "Cor de camada inválida" }
        require(layer.text.length <= 4096) { "Texto excede 4096 caracteres" }
        require(layer.fontSize.isFinite() && layer.fontSize in 1f..2048f) { "Tamanho de fonte inválido" }
        layer.mediaRef?.let { require(isValidMediaReference(it)) { "Referência de mídia inválida" } }
        require(layer.type != LayerType.IMAGE || layer.mediaRef != null) { "Camada de imagem sem referência de mídia" }
        AnimatedProperty.entries.forEach { validatePropertyValue(it, layer.transform.value(it)) }
        require(layer.tracks.size <= AnimatedProperty.entries.size) { "Quantidade inválida de trilhas" }
        require(layer.tracks.map { it.property }.distinct().size == layer.tracks.size) { "Trilhas de animação duplicadas" }
        layer.tracks.forEach { track ->
            require(track.keyframes.size <= ProjectLimits.MAX_KEYFRAMES_PER_TRACK) { "Limite de 256 keyframes por trilha excedido" }
            var previousTime = -1L
            track.keyframes.forEach { keyframe ->
                require(keyframe.timeMs in 0..layer.durationMs) { "Keyframe fora da duração da camada" }
                require(keyframe.timeMs > previousTime) { "Keyframes devem estar ordenados e ter tempos únicos" }
                previousTime = keyframe.timeMs
                validatePropertyValue(track.property, keyframe.value)
                val curve = keyframe.curve
                require(curve.x1.isFinite() && curve.x1 in 0f..1f && curve.x2.isFinite() && curve.x2 in 0f..1f) { "Coordenadas X da curva Bézier inválidas" }
                require(curve.y1.isFinite() && abs(curve.y1) <= 10f && curve.y2.isFinite() && abs(curve.y2) <= 10f) { "Coordenadas Y da curva Bézier inválidas" }
            }
        }
    }
    return this
}

private fun validatePropertyValue(property: AnimatedProperty, value: Float) {
    require(value.isFinite()) { "Valor não finito em $property" }
    val valid = when (property) {
        AnimatedProperty.X, AnimatedProperty.Y -> abs(value) <= 1_000_000f
        AnimatedProperty.SCALE_X, AnimatedProperty.SCALE_Y -> abs(value) <= 100f
        AnimatedProperty.ROTATION -> abs(value) <= 360_000f
        AnimatedProperty.OPACITY -> value in 0f..1f
        AnimatedProperty.ANCHOR_X, AnimatedProperty.ANCHOR_Y -> abs(value) <= 10f
    }
    require(valid) { "Valor fora dos limites de $property" }
}
