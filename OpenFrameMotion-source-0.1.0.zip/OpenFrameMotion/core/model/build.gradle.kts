plugins {
    alias(libs.plugins.kotlin.jvm)
    alias(libs.plugins.kotlin.serialization)
    `java-library`
}
kotlin { jvmToolchain(17) }
dependencies {
    api(libs.serialization.json)
    testImplementation(libs.junit)
}
